﻿using Otsukaele;
using System;
using System.IO;
using System.Text;

namespace FluxMeter3
{
    /// <summary>
    /// Log の概要の説明です。
    /// </summary>
    class Log
    {
        const string format = "yyyyMMdd_HHmmss";

        static Log _instance;

        /// <summary>LogFileDir</summary>
        string _logFileDir => StartUp.GetPath(true, nameof(Log));
        /// <summary>LogFileName</summary>
        string _logFileName => $"{_logFileDir}\\{nameof(Log)}_{DateTime.Now.ToString(format)}.{nameof(Log).ToLower()}";

        StreamWriter _logFileStream;	//ログ書き込みWriter
        FileStream _stream;			//IO書き込み
        int _intValidityTerm;		//ログの保存期間
        DateTime _datLastLogCreate;	//ログファイルの作成日時
        bool _blnLogEnable;

        static object _lockObject = new object();  // ロックオブジェクト

        /// <summary>
        /// ログ書き込みの伝播
        /// </summary>
        public static event Action<string, string, string> addLogEvent;

    
        Log(int intValidityTerm, bool blnEnable)
        {
            Initialize(intValidityTerm, blnEnable);
        }

        /// <summary>
        /// Logクラスの初期化処理
        /// </summary>
        bool Initialize(int intValidityTerm, bool blnEnable)
        {
            _intValidityTerm = intValidityTerm;
            _blnLogEnable = blnEnable;
            try
            {
                if (!Directory.Exists(_logFileDir))
                {
                    Directory.CreateDirectory(_logFileDir);
                }
                _stream = File.Open(_logFileName, FileMode.Create, FileAccess.Write, FileShare.Read);
                _logFileStream = new StreamWriter(_stream, Encoding.GetEncoding("Shift_JIS"));

                _datLastLogCreate = DateTime.Now;

                DeleteLogfile();
                WriteTitle();

            }
            catch (Exception ex)
            {
                AddLog(ex.Message, nameof(Log));
                return false;
            }

            return true;
        }

        /// <summary>
        /// 唯一のインスタンス作成(シングルトン)
        /// </summary>
        public static Log CreateInstance(int intValidTerm, bool blnEnable)
        {
            lock (_lockObject)
            {
                if (_instance == null)
                {
                    _instance = new Log(intValidTerm, blnEnable);
                }
                return _instance;
            }
        }

        /// <summary>
        /// chageDayProc 日時変化時の処理
        /// </summary>
        void ChangeDayProc()
        {
            if (_datLastLogCreate.Day.CompareTo(DateTime.Now.Day) < 0)
            {
                // 最終更新日の変更
                _datLastLogCreate = DateTime.Now;

                //古いログの削除(aaaaa 重い処理なので場所は考慮する Thread・・・)
                //DeleteLog();
                DeleteLogfile();

                // ログファイルの切り替え
                try
                {
                    _logFileStream.Close();
                    _stream =
                        File.Open(_logFileName, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Read);
                    _logFileStream =
                        new StreamWriter(_stream, Encoding.GetEncoding("Shift_JIS"));
                }
                catch (Exception ex)
                {
                    Utility.WriteEventLog(Models.Model.Title + ": (Log Class)", " Daily Logfile Change Error " + ex.Message);
                }
            }
        }

        /// <summary>
        /// addLog ログを書き込む
        /// </summary>
        public void AddLog(string strLog, string strDevice)
        {
            var strDate = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss:ffff");
            if (_blnLogEnable)
            {
                lock (_lockObject)
                {
                    //日時変化時の処理
                    ChangeDayProc();

                    //出力文字列に変換
                    strLog = strLog.Replace("\r\n", "<CRLF>");
                    strLog = strLog.Replace("\r", "<CR>");
                    strLog = strLog.Replace("\n/", "<LF>");
                    strDevice = (strDevice + new string((char)0x20, 10)).Substring(0, 10);

                    var strMessage = $"{strDate} {strDevice} {strLog}";

                    _logFileStream.WriteLine(strMessage);
                    _logFileStream.Flush();
                }
            }
            if (addLogEvent != null)
                addLogEvent(strDate, strDevice, strLog);
        }

        /// <summary>
        /// writeTitle
        /// </summary>
        bool WriteTitle()
        {
            _logFileStream.WriteLine(Models.Model.Title);
            _logFileStream.WriteLine(Utility.GetOsVerion());
            _logFileStream.WriteLine($"--------- Start {Models.Model.Title} {DateTime.Now.ToLocalTime()} ---------");
            _logFileStream.Flush();
            return true;
        }

        /// <summary>
        /// deleteLog 有効期間を過ぎたログを削除する
        /// </summary>
        bool DeleteLog()
        {
            string[] fileEntries;
            try
            {
                fileEntries = Directory.GetFiles(_logFileDir, "*.log");
            }
            catch
            {
                return false;
            }

            foreach (var fileName in fileEntries)
            {
                if (!fileName.Substring(fileName.Length - 3).ToUpper().Equals("LOG")) continue;

                var strDate = fileName.Substring(_logFileName.Length - format.Length - 4, format.Length);
                try
                {
                    var datCreateDate = DateTime.ParseExact(strDate, format, null);
                    datCreateDate = datCreateDate.AddDays(_intValidityTerm);
                    if (datCreateDate.CompareTo(DateTime.Now) < 0)
                    {
                        File.Delete(fileName);
                    }
                }
                catch (Exception ex)
                {
                    AddLog(ex.Message, nameof(Log));
                }
            }

            return true;
        }

        /// <summary>
        /// ファイル削除
        /// </summary>
        bool DeleteLogfile()
        {
            string[] entryFiles;
            // 削除リスト
            try
            {
                entryFiles = Directory.GetFiles(_logFileDir, "*.log");
            }
            catch
            {
                return false;
            }

            if (_intValidityTerm < 1) return true;

            // ログファイルの削除
            foreach (var deleteFile in entryFiles)
            {
                try
                {
                    var lastTime = File.GetLastWriteTime(deleteFile);
                    var validTime = lastTime.AddDays(_intValidityTerm);
                    if (validTime.CompareTo(DateTime.Now) < 0)
                    {
                        File.Delete(deleteFile);
                    }
                }
                catch (Exception ex)
                {
                    AddLog(ex.Message, nameof(Log));
                }
            }

            return true;
        }
    }
}
