﻿using System;
using System.Diagnostics;

namespace FluxMeter3
{
    class Utility
    {
        /// <summary>
        /// OS Versionの取得
        /// </summary>
        public static string GetOsVerion()
        {
            return string.Format("OS {0} Revision {1}",
                Environment.OSVersion.Platform.ToString(),
                Environment.OSVersion.Version.ToString());
        }

        /// <summary>
        /// イベントログの書き込み
        /// </summary>
        public static bool WriteEventLog(string strSource, string strMsg)
        {
            if (!EventLog.SourceExists(Models.Model.Title))
                EventLog.CreateEventSource(Models.Model.Title, "Application");

            EventLog eventLog = new EventLog();
            eventLog.Source = strSource;
            eventLog.WriteEntry(strMsg);

            return true;
        }
    }
}
