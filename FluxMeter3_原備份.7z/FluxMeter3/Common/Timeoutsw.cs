﻿using System;
using System.Diagnostics;

namespace FluxMeter3.Common
{
    class Timeoutsw : IDisposable
    {
        Stopwatch _stopwatch;
        TimeSpan _limitTime;

        public Timeoutsw(double seconds)
        {
            _stopwatch = new Stopwatch();

            var sec = (int)Math.Floor(seconds);
            var msec = (int)Math.Ceiling(seconds);
            _limitTime = new TimeSpan(0, 0, 0, sec, msec);
        }
        ~Timeoutsw()
        {
            Dispose(false);
        }

        #region IDisposable メンバ

        /// <summary>
        /// 破棄
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 破棄
        /// </summary>
        /// <param name="disposing">削除フラグ</param>
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_stopwatch != null)
                {
                    _stopwatch.Reset();
                    _stopwatch = null;
                }
            }
        }

        #endregion

        /// <summary>
        /// スタート
        /// </summary>
        public void Start() => _stopwatch.Start();

        /// <summary>
        /// Restart TimeOut Calc
        /// </summary>
        public void Restart()
        {
            Reset();
            Start();
        }

        /// <summary>
        /// 停止
        /// </summary>
        public void Stop() => _stopwatch.Stop();

        /// <summary>
        /// リセット
        /// </summary>
        public void Reset() => _stopwatch.Reset();

        /// <summary>
        /// タイムアウト
        /// </summary>
        public bool IsTimeout
        {
            get
            {
                if (_stopwatch.Elapsed > _limitTime)
                    return true;

                return false;
            }
        }

        /// <summary>
        /// Disable TimeOut Process
        /// </summary>
        bool _disable;
        public bool Disable
        {
            get { return _disable; }
            set { _disable = value; }
        }
    }
}
