﻿using FluxMeter3.Common;
using FluxMeter3.Models;
using FluxMeter3.Views;
using Otsukaele;
using Otsukaele.MVVM;
using Otsukaele.MVVM.Messaging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class ShowDataValueVM : ViewModelBase
    {
        const int ErrorTimer = 5;
        // For ShowData
        int _idx;
        public string No => _idx.ToString("000");    

        public string Name => _item.Name;

        string _showValue = "";
        public string ShowValue
        {
            get { return _showValue; }
            set { SetProperty(ref _showValue, value); }
        }

        public string Unit => _item.Unit;

        public string AddressToPlc => $"D{3000 + (_idx - 1) * 2}";

        public bool Reset => _item.IsReset;       

        int errorStatus = 0;
        public int ErrorStatus 
        {
            get { return errorStatus; }
            set { SetProperty(ref errorStatus, value); }
        }

        // For Hepa Control
        public int SlaveID => _item.SlaveID;


        MainViewModel _parentvm;
        readonly ShowDataValue _item;
        public ShowDataValueVM(ShowDataValue item, int idx, MainViewModel _vm)
        {
            _idx = idx;
            _item = item;
            _parentvm = _vm;
        }

        Timeoutsw errorTimeout;
        public void Update()
        {
            ResetCommand.OnCanExcecuteChanged();
            // Value Update
            ShowValue = _item.ShowValue.ToString();

            if (!Model.ModbusDevice.IsConnected()) return;
            if (ErrorStatus == _item.Err) return;
            if (ErrorStatus > 0 && _item.Err > 0) return;

            //Show Error Control            
            if (_item.Err == (int)ShowValueErrorDefine.NoError)
            {
                errorTimeout = null;
                ErrorStatus = (int)ShowValueErrorDefine.NoError;            
            }
            else
            {
                if (errorTimeout == null)
                {
                    // Error Show After Keep 5 secs
                    errorTimeout = new Timeoutsw(ErrorTimer);
                    errorTimeout.Start();
                }
                if (errorTimeout.IsTimeout)
                {
                    // Hepa Error Status
                    DeviceType aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), Model.FM_Setting.Devices[SlaveID - 1]);
                    string err_str = "";
                    switch (aEnum)
                    {
                        case DeviceType.AirTechFFU:
                            Airtech_ErrCode airtechErr = Airtech_ErrCode.UnknowError;
                            if (Enum.IsDefined(typeof(Airtech_ErrCode), _item.Err)) airtechErr = (Airtech_ErrCode)_item.Err;
                            err_str = airtechErr.ToAliasName() + ", ErrorCode = " + _item.Err + ", Slave ID = " + _item.SlaveID;
                            ErrorStatus = (int)ShowValueErrorDefine.DeviceError;
                            break;
                        case DeviceType.AAF_EFU:
                            AAF_ErrCode aafErr = AAF_ErrCode.UnknowError;
                            if (Enum.IsDefined(typeof(AAF_ErrCode), _item.Err)) aafErr = (AAF_ErrCode)_item.Err;
                            err_str = aafErr.ToAliasName() + ", ErrorCode = " + _item.Err + ", Slave ID = " + _item.SlaveID;
                            ErrorStatus = (int)ShowValueErrorDefine.DeviceError;
                            break;
                        case DeviceType.MayAir_EA21:
                            MayAir_ErrCode mayAirErr = MayAir_ErrCode.UnknowError;
                            if (Enum.IsDefined(typeof(MayAir_ErrCode), _item.Err)) mayAirErr = (MayAir_ErrCode)_item.Err;
                            err_str = mayAirErr.ToAliasName() + ", ErrorCode = " + _item.Err + ", Slave ID = " + _item.SlaveID;
                            ErrorStatus = (int)ShowValueErrorDefine.DeviceError;
                            break;
                        default:
                            // Normal Device Max & Min
                            if (_item.Err == (int)ShowValueErrorDefine.MaximumError)
                            {
                                err_str = _item.MaxMsg + ", Slave ID = " + _item.SlaveID;
                                ErrorStatus = (int)ShowValueErrorDefine.MaximumError;
                            }
                            if (_item.Err == (int)ShowValueErrorDefine.MinimumError)
                            {
                                err_str = _item.MinMsg + ", Slave ID = " + _item.SlaveID;
                                ErrorStatus = (int)ShowValueErrorDefine.MinimumError;
                            }
                            break;
                    }
                    // Add ErrorCode to ErrorWindow and Log
                    Model.ErrorManager.AddError(new ErrorItem(_idx, _item.Name, err_str));
                    Model.ModbusDevice.AddCommentLog(err_str);                                   
                    errorTimeout = null;
                }
            }
        }

        #region 同步，不會等Key密碼後執行
        //RelayCommand _set_resetCommand;
        //public RelayCommand Set_ResetCommand
        //{
        //    get
        //    {
        //        return _set_resetCommand ?? (_set_resetCommand =
        //                       new RelayCommand(() => Set_ResetExecute()));
        //    }
        //}

        //void Set_ResetExecute()
        //{
        //    CheckPasswordViewModel vm = new CheckPasswordViewModel();
        //    var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
        //                                            vm,
        //                                            topmost: true,
        //                                            startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
        //                                            isDialog: true);
        //    Messenger.SendAsync(args);

        //    if (vm.RESULT == true)
        //    {
        //        Model.EKI_Device.SET_RESET(Item.SlaveID);
        //    }
        //}
        #endregion

        RelayCommandAsync _resetCommand;
        public RelayCommandAsync ResetCommand
        {
            get
            {
                return _resetCommand ?? (_resetCommand =
                               new RelayCommandAsync(() => ResetExecute(),
                               () => !Model.ModbusDevice.IsDeviceCommanding &&
                                     Model.ModbusDevice.IsConnected()));
            }
        }

        async Task ResetExecute()
        {
            #region Unuse Mark : Funtion move to _parentvm
            //CheckPasswordViewModel vm = new CheckPasswordViewModel();
            ////var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
            ////                                        vm,
            ////                                        topmost: true,
            ////                                        startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
            ////                                        isDialog: true);
            ////await Messenger.SendAsync(args).ConfigureAwait(false);
            //if (vm.RESULT == true)
            //{
            //    Model.EKI_Device.SET_RESET(_item.SlaveID);
            //}
            #endregion
            await _parentvm.ResetExecute(_item.SlaveID).ConfigureAwait(false);           
        }
    }
}
