﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsMonthsVM : ViewModelBase
    {      
        public string Name => _item.Name;
        public string Unit => _item.Unit;
        public bool IsSupport => _item.IsSupport;

        bool _isShowChart;
        public bool IsShowChart
        {
            get { return _isShowChart; }
            set { SetProperty(ref _isShowChart, value); }
        }       

        // 每月總和
        public double MonthJanSum => _MonthDataList[0].DataList.Sum();
        public double MonthFebSum => _MonthDataList[1].DataList.Sum();
        public double MonthMarSum => _MonthDataList[2].DataList.Sum();
        public double MonthAprSum => _MonthDataList[3].DataList.Sum();
        public double MonthMaySum => _MonthDataList[4].DataList.Sum();
        public double MonthJunSum => _MonthDataList[5].DataList.Sum();
        public double MonthJulSum => _MonthDataList[6].DataList.Sum();
        public double MonthAugSum => _MonthDataList[7].DataList.Sum();
        public double MonthSepSum => _MonthDataList[8].DataList.Sum();
        public double MonthOctSum => _MonthDataList[9].DataList.Sum();
        public double MonthNovSum => _MonthDataList[10].DataList.Sum();
        public double MonthDecSum => _MonthDataList[11].DataList.Sum();

        // For Chart Use
        public List<double> EveryMonthsSumList => _MonthDataList.Select(x => x.DataList.Sum()).ToList();
        public int Index { get; set; }

        List<DateRecItem> _MonthDataList;
        StatisticsLoadViewModel _parentvm;
        readonly StatisticsItem _item;
        public StatisticsMonthsVM(StatisticsItem item ,int idx, StatisticsLoadViewModel _vm)
        {
            _parentvm = _vm;
            _item = item;
            Index = idx;
            _MonthDataList = _parentvm.StatisticDataFromXml.RecordList.Select(x => x.Statistics[Index]).ToList();
            IsShowChart = true;
        }

        RelayCommand _isShowDataChartCommand;

        public RelayCommand IsShowDataChartCommand
        {
            get
            {
                return _isShowDataChartCommand ?? (_isShowDataChartCommand =
                               new RelayCommand(() => IsShowDataChartExecute()));
            }
        }

        void IsShowDataChartExecute()
        {
            IsShowChart = !IsShowChart;
            _parentvm.MonthChart.RefreshPatten();
            _parentvm.DayChart.RefreshPatten();
        }

    }
}
