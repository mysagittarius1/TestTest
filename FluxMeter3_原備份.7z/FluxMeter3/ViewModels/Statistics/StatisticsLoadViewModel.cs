﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsLoadViewModel : ViewModelBase
    {
        #region Title: Year Month (StatisticsMonthsVM)
        public string TitleYearWithMonth1 => StatisticDataFromXml.MonthList[0].ToString("yyyy/MM");
        public string TitleYearWithMonth2 => StatisticDataFromXml.MonthList[1].ToString("yyyy/MM");
        public string TitleYearWithMonth3 => StatisticDataFromXml.MonthList[2].ToString("yyyy/MM");
        public string TitleYearWithMonth4 => StatisticDataFromXml.MonthList[3].ToString("yyyy/MM");
        public string TitleYearWithMonth5 => StatisticDataFromXml.MonthList[4].ToString("yyyy/MM");
        public string TitleYearWithMonth6 => StatisticDataFromXml.MonthList[5].ToString("yyyy/MM");
        public string TitleYearWithMonth7 => StatisticDataFromXml.MonthList[6].ToString("yyyy/MM");
        public string TitleYearWithMonth8 => StatisticDataFromXml.MonthList[7].ToString("yyyy/MM");
        public string TitleYearWithMonth9 => StatisticDataFromXml.MonthList[8].ToString("yyyy/MM");
        public string TitleYearWithMonth10 => StatisticDataFromXml.MonthList[9].ToString("yyyy/MM");
        public string TitleYearWithMonth11 => StatisticDataFromXml.MonthList[10].ToString("yyyy/MM");
        public string TitleYearWithMonth12 => StatisticDataFromXml.MonthList[11].ToString("yyyy/MM");
        #endregion

        #region Title: Device Name, IsSupport (StatisticDaysVM)
        public string Device1Name => $"{Model.ST_Setting.Statistics[0].Name}\n{Model.ST_Setting.Statistics[0].Unit}";
        public string Device2Name => $"{Model.ST_Setting.Statistics[1].Name}\n{Model.ST_Setting.Statistics[1].Unit}";
        public string Device3Name => $"{Model.ST_Setting.Statistics[2].Name}\n{Model.ST_Setting.Statistics[2].Unit}";
        public string Device4Name => $"{Model.ST_Setting.Statistics[3].Name}\n{Model.ST_Setting.Statistics[3].Unit}";
        public string Device5Name => $"{Model.ST_Setting.Statistics[4].Name}\n{Model.ST_Setting.Statistics[4].Unit}";
        public string Device6Name => $"{Model.ST_Setting.Statistics[5].Name}\n{Model.ST_Setting.Statistics[5].Unit}";
        public string Device7Name => $"{Model.ST_Setting.Statistics[6].Name}\n{Model.ST_Setting.Statistics[6].Unit}";
        public string Device8Name => $"{Model.ST_Setting.Statistics[7].Name}\n{Model.ST_Setting.Statistics[7].Unit}";

        public bool IsDevice1Support => Model.ST_Setting.Statistics[0].IsSupport;
        public bool IsDevice2Support => Model.ST_Setting.Statistics[1].IsSupport;
        public bool IsDevice3Support => Model.ST_Setting.Statistics[2].IsSupport;
        public bool IsDevice4Support => Model.ST_Setting.Statistics[3].IsSupport;
        public bool IsDevice5Support => Model.ST_Setting.Statistics[4].IsSupport;
        public bool IsDevice6Support => Model.ST_Setting.Statistics[5].IsSupport;
        public bool IsDevice7Support => Model.ST_Setting.Statistics[6].IsSupport;
        public bool IsDevice8Support => Model.ST_Setting.Statistics[7].IsSupport;

        string _titleForSelectedMonth;
        public string TitleForSelectedMonth
        {
            get { return _titleForSelectedMonth; }
            set { SetProperty(ref _titleForSelectedMonth, value); }
        }
        #endregion

        public ObservableCollection<StatisticsMonthsVM> MonthsItems { get; set; }

        public ObservableCollection<StatisticsDaysVM> FirstHalfMonthDays { get; set; }
        public ObservableCollection<StatisticsDaysVM> SecondHalfMonthDays { get; set; }

        public MonthChartViewModel MonthChart { get; }
        public DayChartViewModel DayChart { get; }
       
        public StatisticData StatisticDataFromXml { get; set; } = new StatisticData();

        //帶進StatisticsWindowViewModel取Tab_Index
        StatisticsWindowViewModel _parentvm;
        public StatisticsLoadViewModel(StatisticsWindowViewModel vm)
        {
            _parentvm = vm;

            MonthsItems = Model.ST_Setting.Statistics
                        .Select((x, index) => new StatisticsMonthsVM(x, index, this))
                        .Where(x => x.IsSupport)
                        .ToObservable();


            // Chart初期化
            MonthChart = new MonthChartViewModel(this);
            DayChart = new DayChartViewModel(this);

            //預設剛載入取最新這個月[12]
            RefreshDaysData(12);
            // Tabは最初Pageに帰る
            _parentvm.TabIndex = 0;
        }

        #region Month To Days Commands (StatisticsMonthsVM)
        RelayCommand _month1ToDaysCommand;
        public RelayCommand Month1ToDaysCommand
        {
            get
            {
                return _month1ToDaysCommand ?? (_month1ToDaysCommand =
                               new RelayCommand(() => Month1ToDaysExecute()));
            }
        }
        void Month1ToDaysExecute()
        {
            RefreshDaysData(1);
        }
        
        RelayCommand _month2ToDaysCommand;
        public RelayCommand Month2ToDaysCommand
        {
            get
            {
                return _month2ToDaysCommand ?? (_month2ToDaysCommand =
                               new RelayCommand(() => Month2ToDaysExecute()));
            }
        }
        void Month2ToDaysExecute()
        {
            RefreshDaysData(2);
        }

        RelayCommand _month3ToDaysCommand;
        public RelayCommand Month3ToDaysCommand
        {
            get
            {
                return _month3ToDaysCommand ?? (_month3ToDaysCommand =
                               new RelayCommand(() => Month3ToDaysExecute()));
            }
        }
        void Month3ToDaysExecute()
        {
            RefreshDaysData(3);
        }

        RelayCommand _month4ToDaysCommand;
        public RelayCommand Month4ToDaysCommand
        {
            get
            {
                return _month4ToDaysCommand ?? (_month4ToDaysCommand =
                               new RelayCommand(() => Month4ToDaysExecute()));
            }
        }
        void Month4ToDaysExecute()
        {
            RefreshDaysData(4);
        }

        RelayCommand _month5ToDaysCommand;
        public RelayCommand Month5ToDaysCommand
        {
            get
            {
                return _month5ToDaysCommand ?? (_month5ToDaysCommand =
                               new RelayCommand(() => Month5ToDaysExecute()));
            }
        }
        void Month5ToDaysExecute()
        {
            RefreshDaysData(5);
        }

        RelayCommand _month6ToDaysCommand;
        public RelayCommand Month6ToDaysCommand
        {
            get
            {
                return _month6ToDaysCommand ?? (_month6ToDaysCommand =
                               new RelayCommand(() => Month6ToDaysExecute()));
            }
        }
        void Month6ToDaysExecute()
        {
            RefreshDaysData(6);
        }

        RelayCommand _month7ToDaysCommand;
        public RelayCommand Month7ToDaysCommand
        {
            get
            {
                return _month7ToDaysCommand ?? (_month7ToDaysCommand =
                               new RelayCommand(() => Month7ToDaysExecute()));
            }
        }
        void Month7ToDaysExecute()
        {
            RefreshDaysData(7);
        }

        RelayCommand _month8ToDaysCommand;
        public RelayCommand Month8ToDaysCommand
        {
            get
            {
                return _month8ToDaysCommand ?? (_month8ToDaysCommand =
                               new RelayCommand(() => Month8ToDaysExecute()));
            }
        }
        void Month8ToDaysExecute()
        {
            RefreshDaysData(8);
        }

        RelayCommand _month9ToDaysCommand;
        public RelayCommand Month9ToDaysCommand
        {
            get
            {
                return _month9ToDaysCommand ?? (_month9ToDaysCommand =
                               new RelayCommand(() => Month9ToDaysExecute()));
            }
        }
        void Month9ToDaysExecute()
        {
            RefreshDaysData(9);
        }

        RelayCommand _month10ToDaysCommand;
        public RelayCommand Month10ToDaysCommand
        {
            get
            {
                return _month10ToDaysCommand ?? (_month10ToDaysCommand =
                               new RelayCommand(() => Month10ToDaysExecute()));
            }
        }
        void Month10ToDaysExecute()
        {
            RefreshDaysData(10);
        }

        RelayCommand _month11ToDaysCommand;
        public RelayCommand Month11ToDaysCommand
        {
            get
            {
                return _month11ToDaysCommand ?? (_month11ToDaysCommand =
                               new RelayCommand(() => Month11ToDaysExecute()));
            }
        }
        void Month11ToDaysExecute()
        {
            RefreshDaysData(11);
        }

        RelayCommand _month12ToDaysCommand;
        public RelayCommand Month12ToDaysCommand
        {
            get
            {
                return _month12ToDaysCommand ?? (_month12ToDaysCommand =
                               new RelayCommand(() => Month12ToDaysExecute()));
            }
        }
        void Month12ToDaysExecute()
        {
            RefreshDaysData(12);
        }


        void RefreshDaysData(int iMonth)
        {
            int iIdx = iMonth - 1;

            TitleForSelectedMonth = StatisticDataFromXml.MonthList[iIdx].ToString("yyyy/MM");

            _parentvm.TabIndex = 1;

            var daysInMonth = DateTime.DaysInMonth(StatisticDataFromXml.MonthList[iIdx].Year, StatisticDataFromXml.MonthList[iIdx].Month);
            var dailyDataList = new List<StatisticsDaysVM>();
            for (int i = 0; i < daysInMonth; i++)
            {
                dailyDataList.Add(new StatisticsDaysVM()
                {
                    TitleWithDay = "D_" + (i + 1).ToString("00"),
                    Device1DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[0].DataList[i],
                    Device2DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[1].DataList[i],
                    Device3DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[2].DataList[i],
                    Device4DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[3].DataList[i],
                    Device5DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[4].DataList[i],
                    Device6DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[5].DataList[i],
                    Device7DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[6].DataList[i],
                    Device8DayData = StatisticDataFromXml.RecordList[iIdx].Statistics[7].DataList[i],
                });
            }
            FirstHalfMonthDays = dailyDataList.Take(daysInMonth / 2).ToObservable();
            SecondHalfMonthDays = dailyDataList.Skip(daysInMonth / 2).ToObservable();
            OnPropertyChanged(nameof(FirstHalfMonthDays));
            OnPropertyChanged(nameof(SecondHalfMonthDays));

            DayChart.MonthIndex = iIdx;
            DayChart.RefreshPatten();
        }
        #endregion
    }

}
