﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsWindowViewModel : ViewModelBase
    {
        public StatisticsLoadViewModel StatisticsPage { get; set; }

        int _tabIndex;
        public int TabIndex
        {
            get { return _tabIndex; }
            set { SetProperty(ref _tabIndex, value); }
        }

        public StatisticsWindowViewModel()
        {
            TabIndex = 0;
            StatisticsPage = new StatisticsLoadViewModel(this);
        }
    }
}
