﻿using Otsukaele.WPF.Chart;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Media;
using FluxMeter3.Models;

namespace FluxMeter3.ViewModels
{
    class MonthChartViewModel : ViewModelBase
    {
        List<SolidColorBrush> Colors = new List<SolidColorBrush>();

        // Chart View
        public ChartView View { get; } = new ChartView
        {
            YAxisView = { Title = "Value", IsAutoScale = true, Max = 1.0, Min = 0.0 }
        };

        // Series一覧を取得します
        public ObservableCollection<ChartModel> Items { get; private set; } = new ObservableCollection<ChartModel>();

        StatisticsLoadViewModel _parentvm;
        public MonthChartViewModel(StatisticsLoadViewModel _vm)
        {
            Colors.Add(Brushes.Gold);
            Colors.Add(Brushes.SaddleBrown);
            Colors.Add(Brushes.Red);
            Colors.Add(Brushes.Purple);
            Colors.Add(Brushes.Navy);
            Colors.Add(Brushes.Green);
            Colors.Add(Brushes.Firebrick);
            Colors.Add(Brushes.Moccasin);

            _parentvm = _vm;

            View.XAxisView.Title = "Month";
            View.XAxisView.IsAutoScale = false;
            View.XAxisView.Min = 1;
            View.XAxisView.Max = 12;

            RefreshPatten();
        }

        public void RefreshPatten()
        {
            Items.Clear();
            for (int i = 0; i < _parentvm.MonthsItems.Count; i++)
            {
                if (!_parentvm.MonthsItems[i].IsShowChart) continue;

                ChartModel aDeviceChart = new ChartModel(_parentvm.MonthsItems[i].Name, brush: Colors[i]);
                aDeviceChart.Clear();
                aDeviceChart.XValues = Enumerable.Range(1, 12)
                                    .Select(x => (double)x).ToObservableList(); 
                aDeviceChart.YValues = _parentvm.MonthsItems[i].EveryMonthsSumList.ToObservableList();
                Items.Add(aDeviceChart);
            }
        }
    }
}
