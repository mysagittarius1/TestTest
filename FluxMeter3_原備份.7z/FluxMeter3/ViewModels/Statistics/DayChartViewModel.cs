﻿using Otsukaele.WPF.Chart;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Collections.ObjectModel;

namespace FluxMeter3.ViewModels
{
    class DayChartViewModel : ViewModelBase
    {
        List<SolidColorBrush> Colors = new List<SolidColorBrush>();

        public int MonthIndex { get; set; }

        // Chart View
        public ChartView View { get; } = new ChartView
        {
            YAxisView = { Title = "Value", IsAutoScale = true, Max = 1.0, Min = 0.0 }
        };

        // Series一覧を取得します
        public ObservableCollection<ChartModel> Items { get; private set; } = new ObservableCollection<ChartModel>();

        StatisticsLoadViewModel _parentvm;
        public DayChartViewModel(StatisticsLoadViewModel _vm)
        {
            Colors.Add(Brushes.Gold);
            Colors.Add(Brushes.SaddleBrown);
            Colors.Add(Brushes.Red);
            Colors.Add(Brushes.Purple);
            Colors.Add(Brushes.Navy);
            Colors.Add(Brushes.Green);
            Colors.Add(Brushes.Firebrick);
            Colors.Add(Brushes.Moccasin);

            _parentvm = _vm;

            View.XAxisView.Title = "Day";
            View.XAxisView.IsAutoScale = false;
            View.XAxisView.Min = 1;
            View.XAxisView.Max = 31;
        }

        public void RefreshPatten()
        {          
            var selectedYear = _parentvm.StatisticDataFromXml.MonthList[MonthIndex].Year;
            var selectedMonth = _parentvm.StatisticDataFromXml.MonthList[MonthIndex].Month;
            var daysInMonth = DateTime.DaysInMonth(selectedYear, selectedMonth);

            Items.Clear();
            for (int i = 0; i < _parentvm.MonthsItems.Count; i++)
            {
                if (!_parentvm.MonthsItems[i].IsShowChart) continue;               
                ChartModel aDevice = new ChartModel(_parentvm.MonthsItems[i].Name, brush: Colors[i]);
                aDevice.Clear();               
                aDevice.XValues = Enumerable.Range(1, daysInMonth)
                                    .Select(x => (double)x).ToObservableList();

                aDevice.YValues = _parentvm.StatisticDataFromXml.RecordList[MonthIndex]
                                    .Statistics[_parentvm.MonthsItems[i].Index]
                                    .DataList.ToObservableList();

                Items.Add(aDevice);
            }
        }
    }
}
