﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsDaysVM : ViewModelBase
    {
        public string TitleWithDay { get; set; }

        public double Device1DayData { get; set; }
        public double Device2DayData { get; set; }
        public double Device3DayData { get; set; }
        public double Device4DayData { get; set; }
        public double Device5DayData { get; set; }
        public double Device6DayData { get; set; }
        public double Device7DayData { get; set; }
        public double Device8DayData { get; set; }

        public StatisticsDaysVM()
        {

        }
    }
}
