﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Otsukaele.MVVM;
using FluxMeter3.ViewModels;
using FluxMeter3.Models;
using Otsukaele.MVVM.Messaging;

namespace FluxMeter3.ViewModels
{
    class CheckPasswordViewModel : ViewModelBase
    {
        public string CheckPassword { get; set; }

        bool _result;
        public bool Result
        {
            get { return _result; }
            set { SetProperty(ref _result, value); }
        }

        bool _showWrongString;
        public bool ShowWrongString
        {
            get { return _showWrongString; }
            set { SetProperty(ref _showWrongString, value); }
        }


        RelayCommand _checkPasswordCommand;

        public RelayCommand CheckPasswordCommand
        {
            get
            {
                return _checkPasswordCommand ?? (_checkPasswordCommand =
                               new RelayCommand(() => CheckPasswordExecute()));
            }
        }

        void CheckPasswordExecute()
        {
            if (CheckPassword != Model.FM_Setting.PW_Key)
            {
                ShowWrongString = true;
                return;
            }

            var args = new WindowControlMessageArgs(WindowControl.Close);
            Messenger.SendAsync(args);
            Result = true;
        }

    }
}
