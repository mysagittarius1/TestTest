﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class ErrorItemVM : ViewModelBase
    {
        public string Message => _item.Message;
        public string ReceiveTime => _item.ReceiveTime.ToString("yyyy/MM/dd HH:mm:ss");

        int _index;
        public int Index
        {
            get { return _index; }
            set { SetProperty(ref _index, value); }
        }

        readonly ErrorItem _item;
        public ErrorItemVM(ErrorItem item, int index)
        {
            _index = index;
            _item = item;
        }
    }
}
