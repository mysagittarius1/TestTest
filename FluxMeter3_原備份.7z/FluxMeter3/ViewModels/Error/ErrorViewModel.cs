﻿using FluxMeter3.Models;
using FluxMeter3.Views;
using Otsukaele;
using Otsukaele.MVVM;
using Otsukaele.MVVM.Messaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluxMeter3.ViewModels
{
    class ErrorViewModel : ViewModelBase
    {
        public ObservableCollection<ErrorItemVM> Items { get; set; } = new ObservableCollection<ErrorItemVM>();

        public ErrorViewModel()
        {
            WeakEventManager<ObservableCollection<ErrorItem>, NotifyCollectionChangedEventArgs>.AddHandler(Model.ErrorManager.ErrorList, "CollectionChanged", (o, e) =>
            {
                Items = Model.ErrorManager.ErrorList
                    .Reverse()
                    .Select((x, index) => new ErrorItemVM(x, ++index))
                    .ToObservable();

                if (Items.Count == 0 && e.Action == NotifyCollectionChangedAction.Remove)
                {
                    var args = new WindowControlMessageArgs(WindowControl.Close);
                    Messenger.SendAsync(args);
                }
                if (Items.Count == 1 && e.Action == NotifyCollectionChangedAction.Add)
                {
                    var args = new DisplayWindowMessageArgs(typeof(ErrorWindow),
                                dataContext: this,
                                topmost: true,
                                startupLocation: System.Windows.WindowStartupLocation.Manual,
                                isDialog: false);

                    Messenger.SendAsync(args);
                }
                else
                {
                    OnPropertyChanged(nameof(Items));
                }
            });
        }

        RelayCommand _clearallCommand;
        public RelayCommand ClearAllCommand
        {
            get
            {
                return _clearallCommand ?? (_clearallCommand =
                               new RelayCommand(() => ClearAllExecute()));
            }
        }
        void ClearAllExecute()
        {
            Model.ErrorManager.ClearError();

            var args = new WindowControlMessageArgs(WindowControl.Close);
            Messenger.SendAsync(args);
        }
    }
}
