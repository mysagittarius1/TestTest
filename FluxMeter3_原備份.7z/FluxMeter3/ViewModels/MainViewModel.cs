﻿using FluxMeter3.Models;
using FluxMeter3.Views;
using Otsukaele;
using Otsukaele.MVVM;
using Otsukaele.MVVM.Messaging;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace FluxMeter3.ViewModels
{
    class MainViewModel : ViewModelBase
    {
        bool _plcConnnectStatus;
        public bool PlcConnnectStatus
        {
            get { return _plcConnnectStatus; }
            set
            {
                if (_plcConnnectStatus != value)
                    Model.AddLog($"PLC Connect Status: {value}");
                SetProperty(ref _plcConnnectStatus, value);
            }
        }
        bool _modbusGatewayConnaectStatus;
        public bool ModbusGatewayConnaectStatus
        {
            get { return _modbusGatewayConnaectStatus; }
            set
            {
                if (_modbusGatewayConnaectStatus != value)
                    Model.AddLog($"MODBUS Connect Status: {value}");
                SetProperty(ref _modbusGatewayConnaectStatus, value);
            }
        }
        bool _isHepaControl;
        public bool IsHepaControl
        {
            get { return _isHepaControl; }
            set { SetProperty(ref _isHepaControl, value); }
        }      

        public HepaControlViewModel HepaControlViewModel { get; set; }

        public ErrorViewModel ErrorViewModel { get; set; }

        public ObservableCollection<ShowDataValueVM> Items { get; set; }
      

        public MainViewModel()
        {
            Model.Initialize();
            ErrorViewModel = new ErrorViewModel();
            HepaControlViewModel = new HepaControlViewModel();
            ViewInitial();

            Task.Run(() => Update());
        }
        ~MainViewModel()
        {
            Model.ErrorManager.ClearError();
        }

        void Update()
        {
            while (true)
            {
                PlcConnnectStatus = Model.Host.IsConnected;
                ModbusGatewayConnaectStatus = Model.ModbusDevice.IsConnected();
                IsHepaControl = Model.FM_Setting.IsHepaControl;
                ToHepaControlWindowCommand.OnCanExcecuteChanged();

                Items.ForEach(x => x.Update());

                SpinWait.SpinUntil(() => false, 100);
            }
        }


        public void ViewInitial()
        {
            // MainWinodow Show Data
            Items = Model.ShowDataItemList.Select(
                (x, index) => new ShowDataValueVM(x, ++index, this))
                .ToObservable();
            OnPropertyChanged(nameof(Items));
        }

        public async Task ResetExecute(int iSlaveID)
        {
            CheckPasswordViewModel vm = new CheckPasswordViewModel();
            var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
                                                    vm,
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            await Messenger.SendAsync(args).ConfigureAwait(false);

            if (vm.Result == true) Model.ModbusDevice.SetDeviceReset(iSlaveID);          
        }

        #region To Setting Window Button
        
        RelayCommand _hotKeyToAdminSettingWindowCommand;
        public RelayCommand HotKeyToAdminSettingWindowCommand
        {
            get
            {
                return _hotKeyToAdminSettingWindowCommand ?? (_hotKeyToAdminSettingWindowCommand =
                               new RelayCommand(() => HotKeyToAdminSettingWindowExecute()));
            }
        }
        void HotKeyToAdminSettingWindowExecute()
        {
            var args = new DisplayWindowMessageArgs(typeof(SettingWindow),
                                                    new SettingViewModel(this),
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            Messenger.SendAsync(args);
        }
        #endregion

        #region To Statistics Window Button
        RelayCommand _toStatisticsWindowCommand;
        public RelayCommand ToStatisticsWindowCommand
        {
            get
            {
                return _toStatisticsWindowCommand ?? (_toStatisticsWindowCommand =
                               new RelayCommand(() => ToStatisticsWindowExecute()));
            }
        }
        void ToStatisticsWindowExecute()
        {
            var args = new DisplayWindowMessageArgs(typeof(StatisticsWindow),
                                                    new StatisticsWindowViewModel(),
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            Messenger.SendAsync(args);
        }
        #endregion

        #region To Hepa Control Window Button
        RelayCommand _toHepaControlWindowCommand;
        public RelayCommand ToHepaControlWindowCommand
        {
            get
            {
                return _toHepaControlWindowCommand ?? (_toHepaControlWindowCommand =
                                new RelayCommand(() => ToHepaControlWindowExecute(),
                                                 () => Model.ModbusDevice.IsConnected()));
            }
        }
        void ToHepaControlWindowExecute()
        {
            var args = new DisplayWindowMessageArgs(typeof(HepaControlWindow),
                                                    HepaControlViewModel,
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            Messenger.SendAsync(args);
        }
        #endregion

        #region Plc Switch Button
        RelayCommandAsync _plcSwitchCommand;
        public RelayCommandAsync PlcSwitchCommand
        {
            get
            {
                return _plcSwitchCommand ?? (_plcSwitchCommand =
                               new RelayCommandAsync(() => PlcSwitchExecute()));
            }
        }

        async Task PlcSwitchExecute()
        {
            if (Model.Host.IsConnected) return; 

            CheckPasswordViewModel vm = new CheckPasswordViewModel();
            var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
                                                    vm,
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            await Messenger.SendAsync(args).ConfigureAwait(false);

            if (vm.Result == true)
            {
                Model.Host.PLC_Connect();
            }
        }
        #endregion

        #region Modbus Gateway Switch Button
        RelayCommandAsync _modbusGatewaySwitchCommand;
        public RelayCommandAsync ModbusGatewaySwitchCommand
        {
            get
            {
                return _modbusGatewaySwitchCommand ?? (_modbusGatewaySwitchCommand =
                               new RelayCommandAsync(() => ModbusGatewaySwitchExecute()));
            }
        }

        async Task ModbusGatewaySwitchExecute()
        {
            if (Model.ModbusDevice.IsConnected()) return;

            CheckPasswordViewModel vm = new CheckPasswordViewModel();
            var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
                                                    vm,
                                                    topmost: true,
                                                    startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                    isDialog: true);
            await Messenger.SendAsync(args).ConfigureAwait(false);

            if (vm.Result == true)
            {
                Model.ModbusDevice.ModbusGatewayConnect();
            }
        }
        #endregion

        public Func<Task<bool>> CloseConfirmCommandAsync
        {
            get
            {
                return async () =>
                {
                    CheckPasswordViewModel vm = new CheckPasswordViewModel();
                    var args = new DisplayWindowMessageArgs(typeof(CheckPasswordWindow),
                                                            vm,
                                                            topmost: true,
                                                            startupLocation: System.Windows.WindowStartupLocation.CenterScreen,
                                                            isDialog: true);
                    await Messenger.SendAsync(args).ConfigureAwait(false);

                    if (vm.Result == true)
                    {
                        ExecuteTerminate();
                        return true;
                    }
                    return false;
                };
            }
        }

        void ExecuteTerminate()
        {
            Model.ErrorManager.ClearError();
        }
        
    }
}
