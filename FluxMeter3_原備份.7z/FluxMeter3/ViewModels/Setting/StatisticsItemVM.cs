﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsItemVM : ViewModelBase
    {
        public string No { get; set; }

        public bool IsSupport
        {
            get { return _item.IsSupport; }
            set { _item.IsSupport = value; }
        }
        public string Name
        {
            get { return _item.Name; }
            set { _item.Name = value; }
        }
        public string Unit
        {
            get { return _item.Unit; }
            set { _item.Unit = value; }
        }
        public int Address
        {
            get { return _item.Address; }
            set { _item.Address = value; }
        }
        public string ResetDateTime
        {
            get { return _item.ResetDateTime.ToString("yyyy/MM/dd HH:mm:ss"); }
            set { _item.ResetDateTime = Convert.ToDateTime(value); }
        }

        public int SelectedType
        {
            get { return _item.Type; }
            set { _item.Type = value; }
        }
        public ObservableCollection<string> DeviceItemList => Enum.GetValues(typeof(StatisticDataType)).Cast<StatisticDataType>().Select(e => e.ToString()).ToObservable();

        StatisticsItem _item;
        public StatisticsItemVM(StatisticsItem item,int idx)
        {
            No = idx.ToString("000");
            _item = item;
        }
    }
}
