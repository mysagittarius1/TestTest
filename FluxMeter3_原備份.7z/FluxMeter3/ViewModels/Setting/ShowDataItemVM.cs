﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class ShowDataItemVM : ViewModelBase
    {
        public string No { get; set; }

        public bool IsSupport
        {
            get { return _item.IsSupport; }
            set { _item.IsSupport = value; }
        }

        public string Name
        {
            get { return _item.Name; }
            set { _item.Name = value; }
        }

        public string Unit
        {
            get { return _item.Unit; }
            set { _item.Unit = value; }
        }

        public double MaxLimit
        {
            get { return _item.MaxLimit; }
            set { _item.MaxLimit = value; }
        }

        public double MinLimit
        {
            get { return _item.MinLimit; }
            set { _item.MinLimit = value; }
        }

        public double AX
        {
            get { return _item.AX; }
            set { _item.AX = value; }
        }

        public double BY
        {
            get { return _item.BY; }
            set { _item.BY = value; }
        }

        public double ShowMax
        {
            get { return _item.ShowMax; }
            set { _item.ShowMax = value; }
        }

        public string MaxMessage
        {
            get { return _item.MaxMsg; }
            set { _item.MaxMsg = value; }
        }

        public string MinMessage
        {
            get { return _item.MinMsg; }
            set { _item.MinMsg = value; }
        }

        public int SlaveID
        {
            get { return _item.SlaveID; }
            set { _item.SlaveID = value; }
        }

        public int WordNo
        {
            get { return _item.WordNo; }
            set { _item.WordNo = value; }
        }

        public bool IsReset
        {
            get { return _item.IsReset; }
            set { _item.IsReset = value; }
        }

       ShowDataItem _item;
        public ShowDataItemVM(ShowDataItem item, int idx)
        {
            No = idx.ToString("000");
            _item = item;
        }
    }
}
