﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FluxMeter3.ViewModels
{
    class GenernalSettingViewModel : ViewModelBase
    {
        public LampExSetting LampExSetting { get; private set; } = LampExSetting.Load();

        public ObservableCollection<LampExVM> LampExItems { get; set; }

        bool _isTestMode;
        public bool IsTestMode
        {
            get { return _isTestMode; }
            set { SetProperty(ref _isTestMode, value); }
        }

        bool _isDebug;
        public bool IsDebug
        {
            get { return _isDebug; }
            set { SetProperty(ref _isDebug, value); }
        }

        string _ipAddress;
        public string IpAddress
        {
            get { return _ipAddress; }
            set { SetProperty(ref _ipAddress, value); }
        }

        int _portNo;
        public int PortNo
        {
            get { return _portNo; }
            set { SetProperty(ref _portNo, value); }
        }

        int _connectTimeout;
        public int ConnectTimeout
        {
            get { return _connectTimeout; }
            set { SetProperty(ref _connectTimeout, value); }
        }

        int _sendTimeout;
        public int SendTimeout
        {
            get { return _sendTimeout; }
            set { SetProperty(ref _sendTimeout, value); }
        }

        int _receiveTimeout;
        public int ReceiveTimeout
        {
            get { return _receiveTimeout; }
            set { SetProperty(ref _receiveTimeout, value); }
        }

        bool _isReadFromPlc;
        public bool IsReadFromPlc
        {
            get { return _isReadFromPlc; }
            set { SetProperty(ref _isReadFromPlc, value); }
        }

        string _password;
        public string Password
        {
            get { return _password; }
            set { SetProperty(ref _password, value); }
        }

        int _hepaLowRpm;
        public int HepaLowRpm
        {
            get { return _hepaLowRpm; }
            set { SetProperty(ref _hepaLowRpm, value); }
        }

        int _hepaMedRpm;
        public int HepaMedRpm
        {
            get { return _hepaMedRpm; }
            set { SetProperty(ref _hepaMedRpm, value); }
        }

        int _hepaHighRpm;
        public int HepaHighRpm
        {
            get { return _hepaHighRpm; }
            set { SetProperty(ref _hepaHighRpm, value); }
        }

        bool _isHepaControl;
        public bool IsHepaControl
        {
            get { return _isHepaControl; }
            set { SetProperty(ref _isHepaControl, value); }
        }

        bool _isHepaSpeedControlByUser;
        public bool IsHepaSpeedControlByUser
        {
            get { return _isHepaSpeedControlByUser; }
            set { SetProperty(ref _isHepaSpeedControlByUser, value); }
        }

        bool _isHepaControlByDoor;
        public bool IsHepaControlByDoor
        {
            get { return _isHepaControlByDoor; }
            set { SetProperty(ref _isHepaControlByDoor, value); }
        }

        SettingViewModel _parentvm;
        public GenernalSettingViewModel(SettingViewModel _vm)
        {
            _parentvm = _vm;
            IsTestMode = _parentvm.FluxMeter_Setting.IsTestMode;
            IsDebug = _parentvm.FluxMeter_Setting.IsDebug;
            IpAddress = _parentvm.FluxMeter_Setting.IpAddress;
            PortNo = _parentvm.FluxMeter_Setting.PortNo;
            ConnectTimeout = _parentvm.FluxMeter_Setting.ConnTimeout;
            SendTimeout = _parentvm.FluxMeter_Setting.SendTimeout;
            ReceiveTimeout = _parentvm.FluxMeter_Setting.RecvTimeout;
            IsReadFromPlc = _parentvm.FluxMeter_Setting.IsReadFromPLC;
            Password = _parentvm.FluxMeter_Setting.PW_Key;
            HepaLowRpm = _parentvm.FluxMeter_Setting.HepaRPM_L;
            HepaMedRpm = _parentvm.FluxMeter_Setting.HepaRPM_M;
            HepaHighRpm = _parentvm.FluxMeter_Setting.HepaRPM_H;
            IsHepaControl = _parentvm.FluxMeter_Setting.IsHepaControl;
            IsHepaSpeedControlByUser = _parentvm.FluxMeter_Setting.IsHepaSpeedControlByUser;
            IsHepaControlByDoor = _parentvm.FluxMeter_Setting.IsHepaControlByDoor;

            LampExItems = LampExSetting.LampEx.Select(
                    (x, name) => new LampExVM(x, ++name))
                    .ToObservable();

        }

        public void Save()
        {
            // FluxMeter Setting Save           
            _parentvm.FluxMeter_Setting.IsTestMode = IsTestMode;
            _parentvm.FluxMeter_Setting.IsDebug = IsDebug;
            _parentvm.FluxMeter_Setting.IpAddress = IpAddress;
            _parentvm.FluxMeter_Setting.PortNo = PortNo;
            _parentvm.FluxMeter_Setting.ConnTimeout = ConnectTimeout;
            _parentvm.FluxMeter_Setting.SendTimeout = SendTimeout;
            _parentvm.FluxMeter_Setting.RecvTimeout = ReceiveTimeout;
            _parentvm.FluxMeter_Setting.PW_Key = Password;
            _parentvm.FluxMeter_Setting.IsReadFromPLC = IsReadFromPlc;
            _parentvm.FluxMeter_Setting.HepaRPM_L = HepaLowRpm;
            _parentvm.FluxMeter_Setting.HepaRPM_M = HepaMedRpm;
            _parentvm.FluxMeter_Setting.HepaRPM_H = HepaHighRpm;
            _parentvm.FluxMeter_Setting.IsHepaControl = IsHepaControl;
            _parentvm.FluxMeter_Setting.IsHepaSpeedControlByUser = IsHepaSpeedControlByUser;
            _parentvm.FluxMeter_Setting.IsHepaControlByDoor = IsHepaControlByDoor;

            _parentvm.FluxMeter_Setting.Save();
            LampExSetting.Save();                      
        }
    }
}
