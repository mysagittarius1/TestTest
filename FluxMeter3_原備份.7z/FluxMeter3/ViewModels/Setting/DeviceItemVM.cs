﻿using FluxMeter3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Otsukaele;
using Otsukaele.MVVM;

namespace FluxMeter3.ViewModels
{
    class DeviceItemVM : ViewModelBase
    {
        public string SlaveID { get; set; }
        public string Type
        {
            get {
                var aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), ItemType);
                return  string.Format("{0}.{1}", ItemType, aEnum.ToAliasName());
                }
        }

        public int ItemType { get; set; }
        public DeviceItemVM(int item,int idx)
        {
            SlaveID = idx.ToString("000");
            ItemType = item;          
        }
    }
}
