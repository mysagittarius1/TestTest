﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class StatisticsViewModel : ViewModelBase
    {
        public StatisticsSetting ST_Setting { get; private set; } = StatisticsSetting.Load();

        public ObservableCollection<StatisticsItemVM> Items { get; set; }
     
        public StatisticsViewModel()
        {          
            Items = ST_Setting.Statistics.Select(
                (x, index) => new StatisticsItemVM(x, ++index))
                .ToObservable();
        }

        public void Save()
        {
            ST_Setting.Save();
        }
    }
}
