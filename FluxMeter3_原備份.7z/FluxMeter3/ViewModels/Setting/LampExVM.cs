﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class LampExVM : ViewModelBase
    {
        public string Name { get; set; }     

        public int SlaveID
        {
            get { return _item.Reset_SlaveID; }
            set { _item.Reset_SlaveID = value; }
        }

        public int WordNo
        {
            get { return _item.Reset_WordNo; }
            set { _item.Reset_WordNo = value; }
        }

        LampExItem _item;
        public LampExVM(LampExItem item,int name)
        {
            Name = string.Format("LAMP_0{0}_RESET", name);
            _item = item;
        }
    }
}
