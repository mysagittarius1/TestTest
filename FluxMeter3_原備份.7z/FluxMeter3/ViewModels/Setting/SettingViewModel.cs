﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class SettingViewModel : ViewModelBase
    {
        //FluxMeterSetting 給 FluxMeter&Device
        public FluxMeterSetting FluxMeter_Setting { get; set; } = FluxMeterSetting.Load();
        public GenernalSettingViewModel GenernalSetting { get; set; }
        public ShowDataViewModel ShowDatas { get; set; }
        public StatisticsViewModel Statistics { get; set; }
        public DeviceViewModel Devices { get; set; }


        MainViewModel _parentvm;
        public SettingViewModel(MainViewModel _vm)
        {
            _parentvm = _vm;
            GenernalSetting = new GenernalSettingViewModel(this);
            Devices = new DeviceViewModel(this);
            ShowDatas = new ShowDataViewModel();
            Statistics = new StatisticsViewModel();
        }

        RelayCommand _saveCommand;
        public RelayCommand SaveCommand
        {
            get
            {
                return _saveCommand ?? (_saveCommand =
                               new RelayCommand(() => SaveExecute()));
            }
        }
        void SaveExecute()
        {
            // FluxMeter Setting Save
            GenernalSetting.Save();
            Model.FM_Setting = FluxMeter_Setting;
            // Show Data Save
            ShowDatas.Save();
            Model.SD_Setting = ShowDatas.ShowData_Setting;
            Model.Show_Value_Instance();
            // Static Save
            Statistics.Save();
            Model.ST_Setting = Statistics.ST_Setting;

            _parentvm.ViewInitial();
            if (FluxMeter_Setting.IsHepaControl && !Model.ModbusDevice.IsDeviceCommanding)
            {
                //Set RPM Command                    
                Model.ModbusDevice.SetHepaModeDefaultValue();
            }
        }
    }
}
