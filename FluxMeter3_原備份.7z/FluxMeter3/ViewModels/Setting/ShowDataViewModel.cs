﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class ShowDataViewModel : ViewModelBase
    {
        public ShowDataSetting ShowData_Setting { get; private set; } = ShowDataSetting.Load();

        public ObservableCollection<ShowDataItemVM> Items { get; set; }

        public ShowDataViewModel()
        {
            Items = ShowData_Setting.ShowData.Select(
                (x, index) => new ShowDataItemVM(x, ++index))
                .ToObservable();
        }

        public void Save()
        {
            ShowData_Setting.Save();
        }
    }
}
