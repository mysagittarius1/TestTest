﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class DeviceViewModel : ViewModelBase
    {
        //public FluxMeterSetting Devices_Setting { get; set; }
        ObservableCollection<DeviceItemVM> _items;
        public ObservableCollection<DeviceItemVM> Items
        {
            get { return _items; }
            set { SetProperty(ref _items, value); }
        }

        public ObservableCollection<DeviceChangeItemVM> Types { get; set; }

        SettingViewModel _parentvm;
        public DeviceViewModel (SettingViewModel _vm)
        {
            _parentvm = _vm;
            Items = _parentvm.FluxMeter_Setting.Devices.Select(
                (x, index) => new DeviceItemVM(x, ++index))
                .ToObservable();

            Types = Enum.GetValues(typeof(DeviceType))
                    .Cast<DeviceType>()
                    .Select(x => new DeviceChangeItemVM(x))
                    .ToObservable();
                
        }

        int _selectedDeviceIndex;

        public int SelectedDeviceIndex
        {
            get { return _selectedDeviceIndex; }
            set
            {
                _selectedDeviceIndex = value;
                DeviceTypeUpDate();
            }
        }

        string _selectedSlaveID;

        public string SelectedSlaveID
        {
            get { return _selectedSlaveID; }
            set { SetProperty(ref _selectedSlaveID, value); }
        }


        private void DeviceTypeUpDate()
        {
            if (SelectedDeviceIndex < 0) return;
            SelectedSlaveID = Items[SelectedDeviceIndex].SlaveID;

            SelectedType = Types.FirstOrDefault(
                d => d.ItemInt == Items[SelectedDeviceIndex].ItemType);
        }

        DeviceChangeItemVM _selectedType;

        public DeviceChangeItemVM SelectedType
        {
            get { return _selectedType; }
            set { SetProperty(ref _selectedType, value); }
        }

        RelayCommand _changecommand;

        public RelayCommand ChangeCommand
        {
            get
            {
                return _changecommand ?? (_changecommand =
                               new RelayCommand(() => ChangeExecute()));
            }
        }

        void ChangeExecute()
        {
            if (SelectedDeviceIndex < 0) return;
            if (SelectedSlaveID == null) return;
            if (SelectedSlaveID.Equals(string.Empty)) return;
            if (SelectedType == null) return;

             _parentvm.FluxMeter_Setting.Devices[SelectedDeviceIndex] = SelectedType.ItemInt;
             Update();
        }

        private void Update()
        {
            ObservableCollection<DeviceItemVM> aitems = 
                _parentvm.FluxMeter_Setting.Devices.Select(
                 (x, index) => new DeviceItemVM(x, ++index))
                 .ToObservable();    
            if(_items.Count == aitems.Count)
            {
                bool isUpdate = false;
                for(int i = 0;i< _items.Count; i++)
                {
                    if (Items[i].ItemType == aitems[i].ItemType) continue;

                    Items[i] = aitems[i];
                    isUpdate = true;
                }
                if (isUpdate) OnPropertyChanged(nameof(Items));
            } 
            else
            {
                Items = aitems;
            }     
        }
    }
}
