﻿using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class DeviceChangeItemVM : ViewModelBase
    {
        public string TypeString { get; set; }

        public int ItemInt => (int)_item;

        DeviceType _item;
        public DeviceChangeItemVM(DeviceType item)
        {
            _item = item;
            TypeString = string.Format("{0}.{1}", (int)_item, _item.ToAliasName());
        }
    }
}
