﻿using FluxMeter3.Models;
using Otsukaele.MVVM;
using Otsukaele.MVVM.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class UserSettingViewModel : ViewModelBase
    {
        int _hepaHighRpm;
        public int HepaHighRpm
        {
            get { return _hepaHighRpm; }
            set { SetProperty(ref _hepaHighRpm, value); }
        }

        int _hepaMedRpm;
        public int HepaMedRpm
        {
            get { return _hepaMedRpm; }
            set { SetProperty(ref _hepaMedRpm, value); }
        }

        int _hepaLowRpm;
        public int HepaLowRpm
        {
            get { return _hepaLowRpm; }
            set { SetProperty(ref _hepaLowRpm, value); }
        }

        MainViewModel _parentvm;
        public UserSettingViewModel(MainViewModel _vm)
        {
            _parentvm = _vm;
            HepaLowRpm = Model.FM_Setting.HepaRPM_L;
            HepaMedRpm = Model.FM_Setting.HepaRPM_M;
            HepaHighRpm = Model.FM_Setting.HepaRPM_H;
        }

        RelayCommand _updateCommand;
        public RelayCommand UpdateCommand
        {
            get
            {
                return _updateCommand ?? (_updateCommand =
                               new RelayCommand(() => UpdateExecute()));
            }
        }
        void UpdateExecute()
        {
            Model.FM_Setting.HepaRPM_L = HepaLowRpm;
            Model.FM_Setting.HepaRPM_M = HepaMedRpm;
            Model.FM_Setting.HepaRPM_H = HepaHighRpm;
            Model.FM_Setting.Save();
            Model.ModbusDevice.SetHepaModeDefaultValue();

            var args = new MessageBoxMessageArgs(
                                     "Next Auto Change Use New Setting.",
                                     "Confirm",
                                     isViewCancelButton: false,
                                     topmost: true);
            Messenger.SendAsync(args).ConfigureAwait(false);
            // Windows Close
            CancelExecute();
        }

        RelayCommand _cancelCommand;
        public RelayCommand CancelCommand
        {
            get
            {
                return _cancelCommand ?? (_cancelCommand =
                               new RelayCommand(() => CancelExecute()));
            }
        }
        void CancelExecute()
        {
            var args = new WindowControlMessageArgs(WindowControl.Close);
            Messenger.SendAsync(args);
        }
    }
}
