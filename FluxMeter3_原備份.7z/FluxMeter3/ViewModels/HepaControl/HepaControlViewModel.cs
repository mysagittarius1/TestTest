﻿using FluxMeter3.Models;
using Otsukaele;
using Otsukaele.MVVM;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.ViewModels
{
    class HepaControlViewModel : ViewModelBase
    {
        bool _isenable;
        public bool IsEnable
        {
            get { return _isenable; }
            set { SetProperty(ref _isenable, value); }
        }

        string _stationNo;
        public string StationNo
        {
            get { return _stationNo; }
            set { SetProperty(ref _stationNo, value);}
        }

        bool isAllStationStatus;
        public bool IsAllStationStatus
        {
            get { return isAllStationStatus; }
            set { SetProperty(ref isAllStationStatus, value); }
        }

        int _mannulSpeed;
        public int MannulSpeed
        {
            get { return _mannulSpeed; }
            set { SetProperty(ref _mannulSpeed, value); }
        }

        bool _isHepaSpeedControlByUser;
        public bool IsHepaSpeedControlByUser
        {
            get { return _isHepaSpeedControlByUser; }
            set { SetProperty(ref _isHepaSpeedControlByUser, value); }
        }

        public List<int> HepaDeviceList { get; set; } = new List<int>();

        public HepaControlViewModel()
        {          
            // Hepa Slave List
            HepaDeviceList = Model.ShowDataItemList.Where(x => Model.ModbusDevice.ModbusDevicesArray[x.SlaveID - 1] != null
                                                            && Model.ModbusDevice.ModbusDevicesArray[x.SlaveID - 1].IsHepa)
                                                   .OrderBy(x => x.SlaveID)
                                                   .Select(x => x.SlaveID)
                                                   .ToList();
            IsHepaSpeedControlByUser = Model.FM_Setting.IsHepaSpeedControlByUser;
            MannulSpeed = Model.FM_Setting.HepaRPM_H;
            Task.Run(() => Update());
        }

        void Update()
        {
            while (true)
            {
                IsEnable = Model.ModbusDevice.IsConnected();
                CheckStationStatus();
                ButtonRefresh();
                SpinWait.SpinUntil(() => false, 100);
            }
        }      

        int station_no;
        void CheckStationStatus()
        {
            if (!Int32.TryParse(StationNo, out station_no))
            {
                IsAllStationStatus = true;
                StationNo = "ALL";
            }               
        }

        #region Execute 
        RelayCommand _mannulSpeedCommand;
        public RelayCommand MannulSpeedCommand
        {
            get
            {
                return _mannulSpeedCommand ?? (_mannulSpeedCommand =
                               new RelayCommand(() => MannulSpeedExecute(),
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void MannulSpeedExecute()
        {
            if (IsAllStationStatus) Model.ModbusDevice.SetHepaMannulSpeed(0, MannulSpeed);
            else Model.ModbusDevice.SetHepaMannulSpeed(HepaDeviceList[station_no - 1], MannulSpeed);
        }

        RelayCommand _offCommand;
        public RelayCommand OffCommand
        {
            get
            {
                return _offCommand ?? (_offCommand =
                               new RelayCommand(() => OffExecute(), 
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void OffExecute()
        {
            if (IsAllStationStatus) Model.ModbusDevice.SetHepaOff(0);
            else Model.ModbusDevice.SetHepaOff(HepaDeviceList[station_no - 1]);
        }

        RelayCommand _lowSpeedCommand;
        public RelayCommand LowSpeedCommand
        {
            get
            {
                return _lowSpeedCommand ?? (_lowSpeedCommand =
                               new RelayCommand(() => LowSpeedExecute(), 
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void LowSpeedExecute()
        {
            if (IsAllStationStatus) Model.ModbusDevice.SetHepaLowSpeed(0);
            else Model.ModbusDevice.SetHepaLowSpeed(HepaDeviceList[station_no - 1]);      
        }

        RelayCommand _medSpeedCommand;
        public RelayCommand MedSpeedCommand
        {
            get
            {
                return _medSpeedCommand ?? (_medSpeedCommand =
                               new RelayCommand(() => MedSpeedExecute(), 
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void MedSpeedExecute()
        {
            if (IsAllStationStatus) Model.ModbusDevice.SetHepaMedSpeed(0);
            else Model.ModbusDevice.SetHepaMedSpeed(HepaDeviceList[station_no - 1]);
        }

        RelayCommand _highSpeedCommand;
        public RelayCommand HighSpeedCommand
        {
            get
            {
                return _highSpeedCommand ?? (_highSpeedCommand =
                               new RelayCommand(() => HighSpeedExecute(), 
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void HighSpeedExecute()
        {
            if (IsAllStationStatus) Model.ModbusDevice.SetHepaHighSpeed(0);
            else Model.ModbusDevice.SetHepaHighSpeed(HepaDeviceList[station_no - 1]);
        }

        RelayCommand _isAllControlCommand;
        public RelayCommand IsAllControlCommand
        {
            get
            {
                return _isAllControlCommand ?? (_isAllControlCommand =
                               new RelayCommand(() => IsAllControlExecute(),
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void IsAllControlExecute()
        {
            if (StationNo == "ALL")
            {
                StationNo = "1";
                IsAllStationStatus = false;
            }
            else
            {
                StationNo = "ALL";
                IsAllStationStatus = true;
            }
        }

        RelayCommand _previousStationCommand;
        public RelayCommand PreviousStationCommand
        {
            get
            {
                return _previousStationCommand ?? (_previousStationCommand =
                               new RelayCommand(() => PreviousStationExecute(),
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void PreviousStationExecute()
        {
            if (StationNo == "ALL") return;
            if (station_no <= 1) return;
            StationNo = (station_no - 1).ToString();
        }

        RelayCommand _nextStationCommand;
        public RelayCommand NextStationCommand
        {
            get
            {
                return _nextStationCommand ?? (_nextStationCommand =
                               new RelayCommand(() => NextStationExecute(),
                               () => Model.ModbusDevice.IsConnected() && !Model.ModbusDevice.IsDeviceCommanding));
            }
        }
        void NextStationExecute()
        {
            if (StationNo == "ALL") return;
            if (station_no >= HepaDeviceList.Count) return;
            StationNo = (station_no + 1).ToString();
        }

        void ButtonRefresh()
        {
            OffCommand.OnCanExcecuteChanged();
            LowSpeedCommand.OnCanExcecuteChanged();
            MedSpeedCommand.OnCanExcecuteChanged();
            HighSpeedCommand.OnCanExcecuteChanged();
            IsAllControlCommand.OnCanExcecuteChanged();
            PreviousStationCommand.OnCanExcecuteChanged();
            NextStationCommand.OnCanExcecuteChanged();
        }

        #endregion
    }
}

