﻿using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3
{
    /// <summary>
    /// Device Type MODBUS
    /// </summary>
    public enum DeviceType
    {
        [EnumAliasName("None")]
        None,       
        [EnumAliasName("MOXA AD IOLOGIK_E1240")]
        IOLOGIK_E1240,
        [EnumAliasName("Advantech AD ADAM-4017P")]
        ADAM_4017P,     
        [EnumAliasName("Delta Timer Counter ")]
        CTA_4001D,
        [EnumAliasName("OMRON Power KM-50")] 
        KM_50,
        [EnumAliasName("OMRON Temperature E5CC")]
        E5CC,
        [EnumAliasName("AirTech FFU")]
        AirTechFFU,
        [EnumAliasName("AAF EFU")]
        AAF_EFU,
        [EnumAliasName("MayAir EA2.1")]
        MayAir_EA21,
        [EnumAliasName("Delta Power DPM-C530")]
        DPM_C530,
        [EnumAliasName("Delta Barometer DPA-RS485")]
        DPA_RS485,
        [EnumAliasName("Elsie EFP01")]
        EFP01,
    }

    public enum StatisticDataType
    { 
        None = 0,
        Plc = 1,
        KM50_Kwh = 2,
        KM50_V = 3,
        KM50_A = 4,
        KM50_Kvar = 5,
        KM50_Kva = 6,
        DPM_C530_Kwh = 7,
    }

     public enum PowerMeterStatisticsStep
    {
        KM50_KwhStatisticsStart = 2,
        KM50_KwhStatisticsEnd = 1002,
        KM50_VStatisticsStart = 3,
        KM50_VStatisticsEnd = 1003,
        KM50_AStatisticsStart = 4,
        KM50_AStatisticsEnd = 1004,
        KM50_KvarStatisticsStart = 5,
        KM50_KvarStatisticsEnd = 1005,
        KM50_KvaStatisticsStart = 6,
        KM50_KvaStatisticsEnd = 1006,
        DPM_C530_KwhStatisticsStart = 7,
        DPM_C530_KwhStatisticsEnd = 1007,
    }

    public enum EquipmentDoorStatus : int
    {
        None = 0,
        DoorClose = 1,
        DoorOpen = 2,
        EqPoweOff = 3,
    }

    public enum DevicePowerCommand
    {
        Off = 0,
        On = 1,
    }

    public enum CommandDefine
    {
        None = 0,
        [EnumAliasName("Reset Command")]
        ResetCommand = 1,
        [EnumAliasName("Hepa Set Mode Default Value Command")]
        HepaSetModeDefaultValueCommand = 2,
        [EnumAliasName("Hepa Off Command")]
        HepaOffCommand = 3,
        [EnumAliasName("Hepa Low Speed Command")]
        HpeaLowSpeedCommand = 4,
        [EnumAliasName("Hepa Med Speed Command")]
        HpeaMedSpeedCommand = 5,
        [EnumAliasName("Hepa High Speed Command")]
        HpeaHighSpeedCommand = 6,
        [EnumAliasName("Hepa Mannul Speed Command")]
        HepaMannulSpeedCommand = 7,
    }

    public enum ShowValueErrorDefine
    {       
        NoError = 0,     
        OnLimit = 1,
        MaximumError = 2,
        MinimumError = 3,
        DeviceError = 4,
    }

    // KM50通訊說明書 - 英文版p38
    public enum KM50InitialMode
    {
        SettingMode = 0x700,
        MeasureMode = 0x400,
        KwhReset = 0x300,
        SoftReset = 0x9900,
    }

    public enum TempertureModbusAddress
    {
        Temperture = 1,
    }
    public enum TimerModbusAddress
    {
        CumulativeTime = 0x1000 + 1,
    }   
    public enum ADConverterModbusAddress
    {
        Channel1 = 1,
        Channel2 = 2,
        Channel3 = 3,
        Channel4 = 4,
        Channel5 = 5,
        Channel6 = 6,
        Channel7 = 7,
        Channel8 = 8,
    }
    public enum AAFModbusAddress
    {
        // For Truly DC EFU: AAF AstroFan DC Motor
        //PowerSwitch = 1,
        //SpeedSetting = 2,
        //AlarmCode = 4,
        //RPM = 5,   

        // For 上海天馬
        RPM = 2, 
        AlarmCode = 4,
    }

    public enum AirTechModbusAddress
    {
        Current = 3,
        Status = 5,
        RPM = 6,
    }

    public enum MayAirModbusAddress
    {       
        RPM = 11,
        AlarmCode = 107,
    }

    public enum DPA_RS485ModbusAddress
    {
        PV = 0x1000 + 1
    }

    public enum EFP01ModbusAddress
    {
        Flow = 0x5 + 1
    }

    public enum KM50ModbusAddress
    {
        Kwh = 0xc + 1,
        V = 0x0 + 1,
        A = 0x3 + 1,
        PowerFactor = 0x6 + 1,
        Frequency = 0x7 + 1,
        StatisticKwh = 0x2200 + 1,
        StatisticV = 0x3101 + 1,
        StatisticA = 0x3107 + 1,
        StatisticKvar = 0x3015 + 1,
        StatisticKva = 0x3011 + 1,
        SetTime = 0xFF00 + 1,
        ModeSetting = 1,
    }

    public enum DCP_C530ModbusAddress
    {
        SetTime = 0x1 + 1,
        V = 0x10E + 1,
        A = 0x126 + 1,
        Kwh = 0x15c + 1,  
        // 功率因數 - 無單位
        PowerFactor = 0x132 + 1,       
        Frequency = 0x142 + 1,
        // 實功功率 - kW
        RealPower = 0x144 + 1,
        // 虛功功率 - kVAR
        ReactivePower = 0x14c + 1,
        // 視在功率 - kVA
        ApparentPower = 0x154 + 1,
        // Kwh Reset
        KwhReset = 0x1c + 1,
    }

    public enum PowerMeterDataIndex
    {
        Kwh = 0,
        V = 1,
        A = 4,
        ApparentPower = 6,
        PowerFactor = 7,
        Frequency = 8,
        RealPower = 9,
        ReactivePower = 10,
        StatisticKwh = 11,
        StatisticV = 12,
        StatisticA = 13,
        StatisticKvar = 14,
        StatisticKva = 15,
    }
    public enum BaroMeterDataIndex
    {
        PV = 0,
    }
    public enum AirFlowDataIndex
    {
        Flow = 0,
    }
    public enum TempertureDataIndex
    {
        Temperture = 0,
    }
    public enum TimerDataIndex
    {
        CumulativeTime = 0,
    }
    public enum ADConverterDataIndex
    {
        Channel1 = 0,
        Channel2 = 1,
        Channel3 = 2,
        Channel4 = 3,
        Channel5 = 4,
        Channel6 = 5,
        Channel7 = 6,
        Channel8 = 7,
    }
    public enum HepaDataIndex
    {
        RPM = 0,
        RunningStatus = 1,
        SpeedMode = 2,
        HepaAlarm = 3,
    }

    public enum Airtech_ErrCode
    {
        [EnumAliasName("FFU Driver Error or Circuit JumpOut")]
        HardwareError = 1,
        [EnumAliasName("Unknow Error")]
        UnknowError = 999,
    }

    public enum AAF_ErrCode
    {
        //1  通訊錯誤(CPU)
        //2  IPM 過熱
        //3  IPM 溫度偵測過熱
        //4  IPM 模組異常保護(含 Over Current 保護)
        //9  風扇啟動錯誤
        //254  轉速一分鐘內未達設定值
        //255  通訊異常
        [EnumAliasName("EFU Communication Error(CPU)")]
        CommunicationErroCPU = 1,
        [EnumAliasName("IPM Temperture Over1")]
        TempertureOver1 = 2,
        [EnumAliasName("IPM Temperture Over2")]
        TempertureOver2 = 3,
        [EnumAliasName("IPM Module Protect")]
        ModuleProtect = 4,
        [EnumAliasName("EFU Active Error")]
        ActiveError = 9,
        [EnumAliasName("EFU RPM Error")]
        RPMError = 254,
        [EnumAliasName("EFU Communication Error")]
        CommunicationError = 255,
        [EnumAliasName("Unknow Error")]
        UnknowError = 999,
    }

    public enum MayAir_ErrCode
    {
        //1  Input Pressure Over
        //2  Input Pressure Under
        //4  Input Current Over
        //8  Over Temperture
        //10  Driver Error
        //8000  Communication Error
        [EnumAliasName("EFU Input Pressure Over")]
        PressureOver = 1,
        [EnumAliasName("EFU Input Pressure Under")]
        PressureUnder = 2,
        [EnumAliasName("EFU Input Current Over")]
        CurrentOver = 4,
        [EnumAliasName("EFU Over Temperture")]
        OverTemperture = 8,
        [EnumAliasName("EFU Driver Error")]
        DriverError = 10,
        [EnumAliasName("EFU Communication Error")]
        CommunicationError = 8000,
        [EnumAliasName("Unknow Error")]
        UnknowError = 999,
    }


}
