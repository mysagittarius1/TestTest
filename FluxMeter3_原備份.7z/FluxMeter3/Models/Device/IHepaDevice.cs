﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    interface IHepaDevice
    {
        bool HepaMannulSpeedSwitch(int speed);
        bool HepaOff();
        //(EFU)Control Low
        bool HepaLowSpeedSwitch();
        //(EFU)Control Med
        bool HepaMedSpeedSwitch();
        //(EFU)Control High
        bool HepaHighSpeedSwitch();
        //(EFU)Speed Mode Setting
        bool HepaModeDefaultValueSetting();
    }
}
