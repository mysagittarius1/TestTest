﻿using Advantech.Adam;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class IOLOGIK_E1240 : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> adEnumList = EnumValues.Get<ADConverterDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;
        #endregion

        #region Constructors

        public IOLOGIK_E1240(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            // TCP/IP 忽略SlaveID
            //SlaveID = aSlaveID;
            DataArrayMaxLength = adEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.IOLOGIK_E1240.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }
        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = false;
        public bool IsConnected => mAdam.Connected;
        public string DeviceIP { get; set; }

        //DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] ioLogikDataList;
            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                // Read registers (4X references)
                if (mAdam.Modbus().ReadInputRegs((int)ADConverterModbusAddress.Channel1, DataArrayMaxLength, out ioLogikDataList))
                {
                    if (ioLogikDataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + DeviceIP);
                        }
                        return;
                    }                 
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + DeviceIP);
                        IsNull = false;
                    }
                    var setIndex = 0;
                    for (int iCnt = 0; iCnt < DataArrayMaxLength; iCnt++)
                    {
                        setIndex = adEnumList[iCnt];
                        Data[setIndex] = ioLogikDataList[iCnt];
                    }
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + DeviceIP);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        //Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus().ReadInputRegs((int)ADConverterModbusAddress.Channel1, DataArrayMaxLength, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + DeviceIP);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public void Initial() { }
        public bool Reset() => true;
        public bool HepaMannulSpeedSwitch(int speed) => true;
        public bool HepaOff() => true;
        public bool HepaLowSpeedSwitch() => true;
        public bool HepaMedSpeedSwitch() => true;
        public bool HepaHighSpeedSwitch() => true;
        public bool HepaModeDefaultValueSetting() => true;

        #endregion
    }
}
