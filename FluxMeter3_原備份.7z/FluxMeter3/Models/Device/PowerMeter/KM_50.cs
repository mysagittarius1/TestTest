﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Advantech.Adam;
using Advantech.Common;
using System.Threading;
using Otsukaele;

namespace FluxMeter3.Models
{
    class KM_50 : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> powerEnumList = EnumValues.Get<PowerMeterDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;
        #endregion

        #region Constructors

        public KM_50(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            DataArrayMaxLength = powerEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.KM_50.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }

        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = false;
        public string DeviceIP { get; set; }

        public void Initial()
        {
            if (!mAdam.Connected) return;

            bool result = false;
            result = InitialMode(KM50InitialMode.SettingMode);
            if (result) SpinWait.SpinUntil(() => false, 200);
            else
            {
                Model.AddLog("KM-50 Initial Fail: Seting Mode");
                return;
            }
            result = SetDateTime();
            if (result) SpinWait.SpinUntil(() => false, 200);
            else
            {
                Model.AddLog("KM-50 Initial Fail: Date Time Setting");
                return;
            }
            result = InitialMode(KM50InitialMode.MeasureMode);
            if (result) SpinWait.SpinUntil(() => false, 200);
            else
            {
                Model.AddLog("KM-50 Initial Fail: Measure Mode");
                return;
            }
        }

        // DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] kwhDataList;
            int[] otherInfoDataList;
            int[] statisticsDataList;
            bool ret = false;
            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                // Manual Page.125
                // 0000: EV1
                // 0001: EV2
                // 0002: EV3
                // 0003: EC1
                // 0004: EC2
                // 0005: EC3
                // 0006: Power Factor 
                // 0007: Frequency(Hz)
                // 0008: W
                // 0009: kW
                // 000A: var
                // 000B: kvar
                // 000C: kWh
                // Read registers (4X references)

                //Word = 1 (KWH)
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.Kwh, 2, out kwhDataList))
                {                  
                    if (kwhDataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }                 
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;                         
                    }                   
                    Data[(int)PowerMeterDataIndex.Kwh] = kwhDataList[1] | (kwhDataList[0] << 16);
                    FailCount = 0;         
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                //EV、EC、Power Factor、Frequency
                //Word = 2 (EV)、5 (EC)、 8 (Power Factor)、 9 (Frequency)
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.V, 16, out otherInfoDataList))
                {
                    if (otherInfoDataList == null) return;
                    if (IsNull || IsFail) return;

                    // Save Value To Each Data
                    for (int iCnt = 1; iCnt < 9; iCnt++)
                    {
                        switch(iCnt)
                        {
                            case (int)PowerMeterDataIndex.V:
                                Data[(int)PowerMeterDataIndex.V] = otherInfoDataList[(iCnt - 1) * 2 + 1] | (otherInfoDataList[(iCnt - 1) * 2] << 16);
                                break;
                            case (int)PowerMeterDataIndex.A:
                                Data[(int)PowerMeterDataIndex.A] = otherInfoDataList[(iCnt - 1) * 2 + 1] | (otherInfoDataList[(iCnt - 1) * 2] << 16);
                                break;
                            case (int)PowerMeterDataIndex.PowerFactor:
                                Data[(int)PowerMeterDataIndex.PowerFactor] = otherInfoDataList[(iCnt - 1) * 2 + 1] | (otherInfoDataList[(iCnt - 1) * 2] << 16);
                                break;
                            case (int)PowerMeterDataIndex.Frequency:
                                Data[(int)PowerMeterDataIndex.Frequency] = otherInfoDataList[(iCnt - 1) * 2 + 1] | (otherInfoDataList[(iCnt - 1) * 2] << 16);
                                break;
                        }
                    }
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // Statistic
                // Protect STATISTICS_STEP Don't Repeat Accumulation
                if (StatisticsStep > 0 && StatisticsStep < 1000)
                {
                    switch (StatisticsStep)
                    {
                        case (int)PowerMeterStatisticsStep.KM50_KwhStatisticsStart:
                            // KWH
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.StatisticKwh, 2, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticKwh] = kwhDataList[1] | (kwhDataList[0] << 16);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.KM50_KwhStatisticsEnd;
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }                                
                            }
                            break;

                        case (int)PowerMeterStatisticsStep.KM50_VStatisticsStart:
                            // V
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.StatisticV, 10, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticV] = statisticsDataList[1] | (statisticsDataList[0] << 16);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.KM50_VStatisticsEnd;
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }
                            }
                            break;

                        case (int)PowerMeterStatisticsStep.KM50_AStatisticsStart:
                            // A
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.StatisticA, 2, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticA] = statisticsDataList[1] | (statisticsDataList[0] << 16);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.KM50_AStatisticsEnd;
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }
                            }
                            break;
                        case (int)PowerMeterStatisticsStep.KM50_KvarStatisticsStart:
                            // KVAR
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.StatisticKvar, 2, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticKvar] = statisticsDataList[1] | (statisticsDataList[0] << 16);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.KM50_KvarStatisticsEnd;
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }
                            }
                            break;
                        case (int)PowerMeterStatisticsStep.KM50_KvaStatisticsStart:
                            // KVA
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.StatisticKva, 2, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticKva] = statisticsDataList[1] | (statisticsDataList[0] << 16);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.KM50_KvaStatisticsEnd;
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch(Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        // Reset
        public bool Reset()
        {
            return InitialMode(KM50InitialMode.KwhReset);
        }

        // Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;              
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)KM50ModbusAddress.Kwh, 2, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public bool HepaMannulSpeedSwitch(int speed) => true;
        public bool HepaOff() => true;
        public bool HepaLowSpeedSwitch() => true;
        public bool HepaMedSpeedSwitch() => true;
        public bool HepaHighSpeedSwitch() => true;
        public bool HepaModeDefaultValueSetting() => true;

        #endregion

        bool InitialMode(KM50InitialMode iMode)
        {
            try
            {
                if (!mAdam.Connected) return false;
                int iSetting = (int)iMode;
                if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)KM50ModbusAddress.ModeSetting, iSetting)) return false;
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }

        bool SetDateTime()
        {
            if (!mAdam.Connected) return false;

            DateTime aCurrDate = DateTime.Now;
            byte[] bData = new byte[8];
            bData[0] = 0;
            bData[1] = Convert.ToByte(aCurrDate.Year % 100);
            bData[2] = Convert.ToByte(aCurrDate.Month);
            bData[3] = Convert.ToByte(aCurrDate.Day);
            bData[4] = 0;
            bData[5] = 0;
            bData[6] = Convert.ToByte(aCurrDate.Hour);
            bData[7] = Convert.ToByte(aCurrDate.Minute);


            if (!mAdam.Modbus(SlaveID).PresetMultiRegs((int)KM50ModbusAddress.SetTime, 4, 8, bData)) return false;
            return true;
        }

    }
}
