﻿using Advantech.Adam;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class DPM_C530 : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> powerEnumList = EnumValues.Get<PowerMeterDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;
        #endregion

        #region Constructors

        public DPM_C530(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            DataArrayMaxLength = powerEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.DPM_C530.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }

        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = false;
        public string DeviceIP { get; set; }

        public void Initial()
        {
            if (!mAdam.Connected) return;

            bool result = false;

            result = SetDateTime();
            if (result) SpinWait.SpinUntil(() => false, 200);
            else
            {
                Model.AddLog("DPM C530 Initial Fail: Date Time Setting");
                return;
            }
        }

        // DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] dataList;
            int[] statisticsDataList;

            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                // Read registers (4X references)

                // KWH
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.Kwh, 2 , out dataList))
                {
                    if (dataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;
                    }
                    Data[(int)PowerMeterDataIndex.Kwh] = DataToFloatThenInt(dataList);
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // V
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.V, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;                  
                    Data[(int)PowerMeterDataIndex.V] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // A
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.A, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;                  
                    Data[(int)PowerMeterDataIndex.A] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // PowerFactor
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.PowerFactor, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)PowerMeterDataIndex.PowerFactor] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // Frequency
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.Frequency, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)PowerMeterDataIndex.Frequency] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // RealPower
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.RealPower, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)PowerMeterDataIndex.RealPower] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // ReactivePower
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.ReactivePower, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)PowerMeterDataIndex.ReactivePower] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // ApparentPower
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.ApparentPower, 2, out dataList))
                {
                    if (dataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)PowerMeterDataIndex.ApparentPower] = DataToFloatThenInt(dataList);
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // Statistic
                // Protect STATISTICS_STEP Don't Repeat Accumulation
                if (StatisticsStep > 0 && StatisticsStep < 1000)
                {
                    switch (StatisticsStep)
                    {
                        case (int)PowerMeterStatisticsStep.DPM_C530_KwhStatisticsStart:
                            // KWH
                            if (!IsNull)
                            {
                                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.Kwh, 2, out statisticsDataList))
                                {
                                    if (statisticsDataList == null) return;
                                    Data[(int)PowerMeterDataIndex.StatisticKwh] = DataToFloatThenInt(statisticsDataList);
                                    StatisticsStep = (int)PowerMeterStatisticsStep.DPM_C530_KwhStatisticsEnd;
                                    KwhReset();
                                }
                                else
                                {
                                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                                    return;
                                }
                            }
                            break;
                        default:
                            break;
                    }
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        // Reset
        public bool Reset()
        {
            return KwhReset();
        }

        // Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)DCP_C530ModbusAddress.Kwh, 2, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public bool HepaMannulSpeedSwitch(int speed) => true;
        public bool HepaOff() => true;
        public bool HepaLowSpeedSwitch() => true;
        public bool HepaMedSpeedSwitch() => true;
        public bool HepaHighSpeedSwitch() => true;
        public bool HepaModeDefaultValueSetting() => true;

        #endregion

        bool SetDateTime()
        {
            if (!mAdam.Connected) return false;
            DateTime aCurrDate = DateTime.Now;
            byte[] bData = new byte[8];
            bData[0] = Convert.ToByte(aCurrDate.Year % 100);
            bData[1] = Convert.ToByte(aCurrDate.Month);
            bData[2] = Convert.ToByte(aCurrDate.Day);
            bData[3] = Convert.ToByte((int)aCurrDate.DayOfWeek + 1);
            bData[4] = Convert.ToByte(aCurrDate.Hour);
            bData[5] = Convert.ToByte(aCurrDate.Minute);
            bData[6] = 0;
            bData[7] = 0;

            if (!mAdam.Modbus(SlaveID).PresetMultiRegs((int)DCP_C530ModbusAddress.SetTime, 4, 8, bData)) return false;
            return true;
        }

        // IEEE784 Format 
        int DataToFloatThenInt(int[] data)
        {
            var combineData = data[0] | (data[1] << 16);
            var floatValue = BitConverter.ToSingle(BitConverter.GetBytes(combineData), 0);
            var returnIntValue = Math.Round(floatValue, 3, MidpointRounding.AwayFromZero) * 1000;
            return (int)returnIntValue;
        }

        bool KwhReset()
        {
            try
            {
                if (!mAdam.Connected) return false;
                if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)DCP_C530ModbusAddress.KwhReset, 2)) return false;
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
    }
}
