﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    /// <summary>
    /// for Modbus Master Device Interface
    /// </summary>
    interface IModbusDevice : IHepaDevice
    {
        #region Property
        // 名　取得
        string DeviceName { get; set; }
        // バージョン　取得
        string DeviceVersion { get; set; }
        // Slave No
        int SlaveID { get; set; }
        // 資料バッファー
        int[] Data { get; set; }
        // 統計ステップ
        int StatisticsStep { get; set; }
        // Is DeviceData Receive Null
        bool IsNull { get; set; }
        // Is DeviceData Receive Fail
        bool IsFail { get; set; }
        // Receive Fail Count
        int FailCount { get; set; }
        // Is Hepa Device
        bool IsHepa { get; set; }
        // Device IP
        string DeviceIP { get; set; }
        #endregion

        #region Method
        // Data Refresh
        void DataRefresh();
        // Reset機能
        bool Reset();
        // Other Demand Initial
        void Initial();
        // Device Recovery機能
        void Recovery();
        #endregion
    }
}
