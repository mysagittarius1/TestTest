﻿using Advantech.Adam;
using FluxMeter3.Common;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class ModbusGateway
    {
        const int SocketDeviceCount = 10;
        AdamSocket modbusGatewaySocket;
        AdamSocket[] deviceSocket = new AdamSocket[SocketDeviceCount];
        Dictionary<int, AdamSocket> deviceSocketDictionary = new Dictionary<int, AdamSocket>();
        public IModbusDevice[] ModbusDevicesArray = new IModbusDevice[Model.FM_Setting.Devices.Length];
        public int[] HepaMannulSpeedArray = new int[Model.FM_Setting.Devices.Length];
        public bool isIntialized = false;
        public bool IsDeviceCommanding = false;
        public bool IsEki = false; // For EKI Cycle Wait Use(不等待會當)
        public bool IsHepaMayAir = false; // Hepa Auto Control By Door Status
        const int RecoveryCheckMaxTime = 10;
        int _recoveryCheckCount = 0;
        CommandDefine[] DeviceCommandArray;

        public bool IsConnected()
        {
            if (Model.FM_Setting.IsDebug) return false;
            return modbusGatewaySocket.Connected;
        }

        public ModbusGateway()
        {
            DeviceCommandArray = Enumerable.Repeat(CommandDefine.None, Model.FM_Setting.Devices.Length).ToArray();
            Task.Run(() => ModbusGatewayTask());
        }

        public void Initialize()
        {
            // ModbusGateway 接続
            if (!ModbusGatewayConnect()) return;

            // ModbusGateway Device初期化
            try
            {
                var iLampCnt = 0;
                for (var i = 0; i < Model.FM_Setting.Devices.Length; i++)
                {
                    /*
                     Address Setting
                     1 ~ 20 - KM50C、CTA4001D、E5CC...
                     21 ~ 30 - IOLOGIK_E1240
                     31 ~ 40 - 保留
                     41 ~ 60 - FFU
                    */
                    var aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), Model.FM_Setting.Devices[i]);
                    switch (aEnum)
                    {
                        case DeviceType.IOLOGIK_E1240:
                            ModbusDevicesArray[i] = new IOLOGIK_E1240(i + 1, deviceSocketDictionary[i]);
                            IsEki = false;
                            break;
                        case DeviceType.KM_50:
                            ModbusDevicesArray[i] = new KM_50(i + 1, modbusGatewaySocket);
                            // Initial : DateTime Setting
                            ModbusDevicesArray[i].Initial();
                            break;
                        case DeviceType.DPM_C530:
                            ModbusDevicesArray[i] = new DPM_C530(i + 1, modbusGatewaySocket);
                            ModbusDevicesArray[i].Initial();
                            break;
                        case DeviceType.AirTechFFU:
                            ModbusDevicesArray[i] = new AirTechFFU(i + 1, modbusGatewaySocket);
                            break;
                        case DeviceType.AAF_EFU:
                            ModbusDevicesArray[i] = new AAF_EFU(i + 1, modbusGatewaySocket);
                            break;
                        case DeviceType.MayAir_EA21:
                            ModbusDevicesArray[i] = new MayAir_EA21(i + 1, modbusGatewaySocket);
                            IsHepaMayAir = true;
                            break;
                        case DeviceType.ADAM_4017P:
                            ModbusDevicesArray[i] = new ADAM_4017P(i + 1, modbusGatewaySocket);
                            IsEki = true;
                            break;
                        case DeviceType.CTA_4001D:
                            ModbusDevicesArray[i] = new CTA_4001D(i + 1, modbusGatewaySocket);
                            ((CTA_4001D)ModbusDevicesArray[i]).RstSlaveID = Model.LE_Setting.LampEx[iLampCnt].Reset_SlaveID;
                            ((CTA_4001D)ModbusDevicesArray[i]).RstWordNo = Model.LE_Setting.LampEx[iLampCnt].Reset_WordNo;
                            iLampCnt++;
                            break;
                        case DeviceType.E5CC:
                            ModbusDevicesArray[i] = new E5CC(i + 1, modbusGatewaySocket);
                            break;
                        case DeviceType.DPA_RS485:
                            ModbusDevicesArray[i] = new DPA_RS485(i + 1, modbusGatewaySocket);
                            break;
                        case DeviceType.EFP01:
                            ModbusDevicesArray[i] = new EFP01(i + 1, modbusGatewaySocket);
                            break;
                        case DeviceType.None:
                        default:
                            ModbusDevicesArray[i] = null;
                            break;
                    }
                }

                isIntialized = true;
            }
            catch (Exception ex)
            {
                Model.AddLog(ex.Message);
                isIntialized = false;
            }
        }

        public bool ModbusGatewayConnect()
        {
            if (Model.FM_Setting.IsDebug) return true;

            try
            {
                // GateWay Socket連線
                modbusGatewaySocket = new AdamSocket();
                // 接続設定
                modbusGatewaySocket.SetTimeout(Model.FM_Setting.ConnTimeout, Model.FM_Setting.SendTimeout, Model.FM_Setting.RecvTimeout);
                // 接続中止
                if (modbusGatewaySocket.Connected) modbusGatewaySocket.Disconnect();
                // Tcp接続
                if (!modbusGatewaySocket.Connect(Model.FM_Setting.IpAddress, ProtocolType.Tcp, 502))
                {
                    Model.AddLog("Gateway Connect Error, IP：" + Model.FM_Setting.IpAddress);
                    return false;
                }

                // Dictionary紀錄個別Socket
                var tcpDeviceCount = 0;
                for (int i = 0; i < Model.FM_Setting.Devices.Length; i++)
                {
                    DeviceType aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), Model.FM_Setting.Devices[i]);
                    switch(aEnum)
                    {
                        case DeviceType.IOLOGIK_E1240:
                            deviceSocket[tcpDeviceCount] = new AdamSocket();
                            deviceSocketDictionary.Add(i, deviceSocket[tcpDeviceCount]);
                            tcpDeviceCount++;
                            break;
                    }
                }

                // Device Socket連線
                if (deviceSocketDictionary != null)
                {
                    foreach (var item in deviceSocketDictionary)
                    {
                        // 接続設定
                        item.Value.SetTimeout(Model.FM_Setting.ConnTimeout, Model.FM_Setting.SendTimeout, Model.FM_Setting.RecvTimeout);
                        // 接続中止
                        if (item.Value.Connected) item.Value.Disconnect();
                        // Tcp接続
                        var connectIp = "192.168.20." + (item.Key + 1);
                        if (!item.Value.Connect(connectIp, ProtocolType.Tcp, 502))
                        {
                            Model.AddLog("Device Connect Error, IP：" + connectIp);
                            return false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Model.AddLog(ex.Message);
                return false;
            }
            return true;
        }
      
        void ModbusGatewayTask()
        {       
            while (true)
            {
                DevicesMonitor();
                SpinWait.SpinUntil(() => false, 50);
            }
        }

        public void SetDeviceReset(int iIdx)
        {
            if (iIdx < 1) return;
            if (iIdx > Model.FM_Setting.Devices.Length) return;
            DeviceCommandArray[iIdx - 1] = CommandDefine.ResetCommand;
            IsDeviceCommanding = true;
        }

        void CheckRecovery()
        {
            if (!isIntialized) return;
            if (Model.FM_Setting.IsDebug) return;
            if (!modbusGatewaySocket.Connected) return;

            var fail_list = ModbusDevicesArray.Where(x => x != null && x.IsFail == true).ToList();
            if (fail_list.Count < 1) return;
            foreach (var item in fail_list) item.Recovery();
        }

        void DevicesMonitor()
        {
            if (!isIntialized) return;
            if (!IsConnected()) return;

            // Auto Control By Door IO For BOE B17
            HepaControlByDoorStatus();

            // Normal Read
            if (!IsDeviceCommanding)
            {
                DeviceDataDataRefresh();
                DeviceConnectRecoveryCheck();
            }

            // Device Command Execute
            if (IsDeviceCommanding)
            {
                DeviceCommandExecute();
                IsDeviceCommanding = false;              
            }
        }

        void HepaControlByDoorStatus()
        {
            if (!Model.FM_Setting.IsHepaControlByDoor) return;
            
            // MayAir EFU Auto Control By Door
            if (Model.Host.IsDoorStatusChange && IsHepaMayAir)
            {
                for (int i = 0; i < ModbusDevicesArray.Length; i++)
                {
                    if (ModbusDevicesArray[i] == null) continue;
                    if (ModbusDevicesArray[i].IsFail) continue;
                    var aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), Model.FM_Setting.Devices[i]);
                    if (aEnum != DeviceType.MayAir_EA21) continue;
                    var doorStatus = Model.Host.DoorStatus;
                    if (doorStatus == EquipmentDoorStatus.DoorOpen || doorStatus == EquipmentDoorStatus.EqPoweOff)
                        DeviceCommandArray[i] = CommandDefine.HpeaHighSpeedCommand;  //High
                    else if (doorStatus == EquipmentDoorStatus.DoorClose)
                        DeviceCommandArray[i] = CommandDefine.HpeaLowSpeedCommand; //Low
                    else continue;
                }
                IsDeviceCommanding = true;
                Model.Host.IsDoorStatusChange = false;
            }
        }

        void DeviceDataDataRefresh()
        {
            // Modbus Device Data Refresh
            for (int i = 0; i < ModbusDevicesArray.Length; i++)
            {
                if (ModbusDevicesArray[i] == null) continue;
                if (ModbusDevicesArray[i].IsFail) continue;
                ModbusDevicesArray[i].DataRefresh();
            }
        }

        void DeviceConnectRecoveryCheck()
        {
            // Device Recovery Check Every 10 Cycle. Now For Lamp Counter Use.
            _recoveryCheckCount++;
            if (_recoveryCheckCount == RecoveryCheckMaxTime)
            {
                CheckRecovery();
                _recoveryCheckCount = 0;
            }
        }

        void DeviceCommandExecute()
        {
            for (int i = 0; i < DeviceCommandArray.Length; i++)
            {
                if (ModbusDevicesArray[i] == null) continue;
                bool isSuccess = false;
                // If Device Fail Cancel Command
                if (ModbusDevicesArray[i].IsFail)
                {
                    if (DeviceCommandArray[i] == CommandDefine.None) continue;
                    var errString = string.Format("{0} {1}, SlaveID = {2}",
                        ModbusDevicesArray[i].DeviceName, DeviceCommandArray[i].ToAliasName() + " Fail", ModbusDevicesArray[i].SlaveID);
                    AddCommentLog(errString);
                    DeviceCommandArray[i] = CommandDefine.None;
                    continue;
                }
                // Device Command Execute
                switch (DeviceCommandArray[i])
                {
                    case CommandDefine.ResetCommand: //Reset Command   
                        if (ModbusDevicesArray[i].Reset())
                            isSuccess = true;
                        break;
                    case CommandDefine.HepaSetModeDefaultValueCommand: //Set RPM Command(Now Only For AirTech)     
                        if (ModbusDevicesArray[i].HepaModeDefaultValueSetting())
                            isSuccess = true;
                        break;
                    case CommandDefine.HepaOffCommand: //Set Off Command 
                        if (ModbusDevicesArray[i].HepaOff())
                            isSuccess = true;
                        break;
                    case CommandDefine.HpeaLowSpeedCommand: //Set Low Command 
                        if (ModbusDevicesArray[i].HepaLowSpeedSwitch())
                            isSuccess = true;
                        break;
                    case CommandDefine.HpeaMedSpeedCommand: //Set Med Command 
                        if (ModbusDevicesArray[i].HepaMedSpeedSwitch())
                            isSuccess = true;
                        break;
                    case CommandDefine.HpeaHighSpeedCommand: //Set High Command 
                        if (ModbusDevicesArray[i].HepaHighSpeedSwitch())
                            isSuccess = true;
                        break;
                    case CommandDefine.HepaMannulSpeedCommand: //Set Mannul Command 
                        var speed = HepaMannulSpeedArray[i];
                        if (ModbusDevicesArray[i].HepaMannulSpeedSwitch(speed))
                            isSuccess = true;
                        break;
                    default:
                        continue;
                }              
                if (isSuccess) DeviceCommandArray[i] = CommandDefine.None;
            }
        }
        
        public int GetData(int iSlave, int iWord)
        {
            // iSlave、iWord都是從1開始，故在Array取值需用iWord - 1
            int ret = 0;

            if (iSlave < 1) return ret;
            if (iSlave > ModbusDevicesArray.Length) return ret;
            if (ModbusDevicesArray[iSlave - 1] == null) return ret;

            if (iWord < 1) return ret;
            if (iWord > ModbusDevicesArray[iSlave - 1].Data.Length) return ret;
            
            ret = ModbusDevicesArray[iSlave - 1].Data[iWord - 1];
            return ret;
        }

        #region Statistics Use
        // iSlave、iWord都是從1開始，故在Array取值需用iWord - 1
        public int GetStaticData(int iSlave, int iWord)
        {
            int ret = 0;

            if (iSlave < 1) return ret;
            if (iSlave > ModbusDevicesArray.Length) return ret;
            if (ModbusDevicesArray[iSlave - 1] == null) return ret;
            if (ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.KM_50.ToAliasName() ||
                ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.DPM_C530.ToAliasName()) return ret;

            if (iWord < 1) return ret;
            if (iWord > ModbusDevicesArray[iSlave - 1].Data.Length) return ret;

            ret = ModbusDevicesArray[iSlave - 1].Data[iWord - 1];
            return ret;
        }

        // iSlave、iWord都是從1開始，故在Array取值需用iWord - 1
        public bool SetStatisticsStep(int iSlave, int iStep)
        {
            bool ret = false;

            if (iSlave < 1) return ret;
            if (iSlave > ModbusDevicesArray.Length) return ret;
            if (ModbusDevicesArray[iSlave - 1] == null) return ret;
            if (ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.KM_50.ToAliasName() || 
                ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.DPM_C530.ToAliasName()) return ret;

            if (ModbusDevicesArray[iSlave - 1].StatisticsStep == 0)
            {
                ModbusDevicesArray[iSlave - 1].StatisticsStep = iStep;
                ret = true;
            }
            return ret;
        }

        // iSlave、iWord都是從1開始，故在Array取值需用iWord - 1
        public void ResetStatisticsStep(int iSlave)
        {
            ModbusDevicesArray[iSlave - 1].StatisticsStep = 0;
        }

        // iSlave、iWord都是從1開始，故在Array取值需用iWord - 1
        public int GetStatisticsStep(int iSlave)
        {
            int ret = 0;
            if (iSlave < 1) return ret;
            if (iSlave > ModbusDevicesArray.Length) return ret;
            if (ModbusDevicesArray[iSlave - 1] == null) return ret;
            if (ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.KM_50.ToAliasName() ||
                ModbusDevicesArray[iSlave - 1].DeviceName != DeviceType.DPM_C530.ToAliasName()) return ret;
            ret = ModbusDevicesArray[iSlave - 1].StatisticsStep;
            return ret;
        }
        #endregion

        #region Set Function From HepaControlViewModel       
        public void SetHepaMannulSpeed(int deviceIndex, int speed)
        {
            if (deviceIndex > Model.FM_Setting.Devices.Length) return;

            if (deviceIndex == 0)
            {
                for (int i = 0; i < ModbusDevicesArray.Length; i++)
                {
                    if (ModbusDevicesArray[i] == null) continue;
                    if (ModbusDevicesArray[i].IsFail) continue;
                    if (ModbusDevicesArray[i].IsHepa) HepaMannulSpeedArray[i] = speed;
                }
            }
            else HepaMannulSpeedArray[deviceIndex - 1] = speed;
            HepaControlExecute(CommandDefine.HepaMannulSpeedCommand, deviceIndex);
        }

        public void SetHepaOff(int deviceIndex)
        {
            if (deviceIndex > Model.FM_Setting.Devices.Length) return;
            HepaControlExecute(CommandDefine.HepaOffCommand, deviceIndex);
        }

        public void SetHepaLowSpeed(int deviceIndex)
        {
            if (deviceIndex > Model.FM_Setting.Devices.Length) return;
            HepaControlExecute(CommandDefine.HpeaLowSpeedCommand, deviceIndex);
        }

        public void SetHepaMedSpeed(int deviceIndex)
        {
            if (deviceIndex > Model.FM_Setting.Devices.Length) return;
            HepaControlExecute(CommandDefine.HpeaMedSpeedCommand, deviceIndex);
        }

        public void SetHepaHighSpeed(int deviceIndex)
        {
            if (deviceIndex > Model.FM_Setting.Devices.Length) return;
            HepaControlExecute(CommandDefine.HpeaHighSpeedCommand, deviceIndex);
        }

        public void SetHepaModeDefaultValue()
        {
            HepaControlExecute(CommandDefine.HepaSetModeDefaultValueCommand, 0);
        }

        void HepaControlExecute(CommandDefine command, int deviceIndex)
        {          
            // Group Control
            if (deviceIndex == 0)
            {
                for (int i = 0; i < ModbusDevicesArray.Length; i++)
                {
                    if (ModbusDevicesArray[i] == null) continue;
                    if (ModbusDevicesArray[i].IsFail) continue;

                    // SetRPMCommand Only For AirTechFFU
                    if (command == CommandDefine.HepaSetModeDefaultValueCommand)
                    {
                        var aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), Model.FM_Setting.Devices[i]);
                        if (aEnum != DeviceType.AirTechFFU) return;
                    }
                    if (ModbusDevicesArray[i].IsHepa) DeviceCommandArray[i] = command;
                }
            }
            // Single Control
            else
            {
                if (ModbusDevicesArray[deviceIndex - 1].IsFail) return;
                DeviceCommandArray[deviceIndex - 1] = command;
            }
            IsDeviceCommanding = true;
        }

        #endregion


        const string LogName = "ModbusGateway";
        /// <summary>
        /// ログ追加
        /// </summary>
        public void AddCommentLog(string msg) => Model.AddLog($"{LogName}:{msg}");
    }
}
