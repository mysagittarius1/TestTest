﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Advantech.Adam;
using Advantech.Common;
using System.Threading;
using Otsukaele;

namespace FluxMeter3.Models
{
    class CTA_4001D : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> timerEnumList = EnumValues.Get<TimerDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;

        #endregion

        #region Constructors

        public CTA_4001D(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            DataArrayMaxLength = timerEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.CTA_4001D.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }
        public int RstSlaveID { get; set; }
        public int RstWordNo { get; set; }
        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = false;
        public string DeviceIP { get; set; }

        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] timerList;
            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                // Read registers (4X references)
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)TimerModbusAddress.CumulativeTime, 2, out timerList))
                {
                    // Null處理
                    if (timerList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }
                    // Normal處理
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;
                    }                  
                    Data[(int)TimerDataIndex.CumulativeTime] = (timerList[1] * 65535 + timerList[0]);
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);                       
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch(Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        //Reset
        public bool Reset()
        {
            try
            {
                if (!mAdam.Connected) return false;
                //Reset, 需接PLC IO觸發RST
                #region 此為無用Code
                //if (!mAdam.Modbus(RstSlaveID).ForceSingleCoil(16 + RstWordNo, true)) return false;
                //System.Threading.Thread.Sleep(100);
                //if (!mAdam.Modbus(RstSlaveID).ForceSingleCoil(16 + RstWordNo, false)) return false; 
                #endregion
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }

        //Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)TimerDataIndex.CumulativeTime, 2, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public void Initial() { }
        public bool HepaMannulSpeedSwitch(int speed) => true;
        public bool HepaOff() => true;
        public bool HepaLowSpeedSwitch() => true;
        public bool HepaMedSpeedSwitch() => true;
        public bool HepaHighSpeedSwitch() => true;
        public bool HepaModeDefaultValueSetting() => true;

        #endregion
    }
}
