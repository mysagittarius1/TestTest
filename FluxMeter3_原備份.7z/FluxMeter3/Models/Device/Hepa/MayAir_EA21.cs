﻿using Advantech.Adam;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class MayAir_EA21 : IModbusDevice
    {
        #region Member

        const int DataArrayMaxLength = 40;
        const int MaxHepaCount = 20;
        const int FailRetryTime = 10;
        int mayAirControllerSlaveID = 0;
        int deviceNo = 0;
        AdamSocket mAdam;
        MayAir_EA21 mayAirController;
        #endregion

        #region Constructors
        public MayAir_EA21(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            // Get Controller SlaveID
            // MayAir Slave其實只有控制器，其餘SlaveID作為DataArray取數值用
            mayAirControllerSlaveID = Model.ModbusDevice.ModbusDevicesArray.Where(x => x.DeviceName == DeviceType.MayAir_EA21.ToAliasName())
                                .First().SlaveID;
            deviceNo = SlaveID % mayAirControllerSlaveID;
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.MayAir_EA21.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; } = new int[DataArrayMaxLength];
        public int StatisticsStep { get; set; }
        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = true;
        public string DeviceIP { get; set; }

        // DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] rpmDataList;
            int[] alarmDataList;
            if (FailCount >= FailRetryTime) FailCount = 0;

            // Get Controller
            if (mayAirController == null)
                mayAirController = (MayAir_EA21)Model.ModbusDevice.ModbusDevicesArray
                                .Where(x => x.DeviceName == DeviceType.MayAir_EA21.ToAliasName())
                                .First();
            IsNull = mayAirController.IsNull;
            Data[(int)HepaDataIndex.RPM] = mayAirController.Data[deviceNo];
            Data[(int)HepaDataIndex.HepaAlarm] = mayAirController.Data[deviceNo + MaxHepaCount];

            try
            {
                // 檢查是否為控制器的SlaveID
                if (SlaveID != mayAirControllerSlaveID) return;

                // Read registers (4X references)
                //Max EFU Count is 20
                //mayAirDevice.Data[0~19] is RPM
                //mayAirDevice.Data[20~39] is Err             
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)MayAirModbusAddress.RPM, MaxHepaCount, out rpmDataList))
                {
                    // Null處理
                    if (rpmDataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }
                    // Normal處理
                    if (IsNull)
                    {
                        // Initial or Recovery Log
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;
                    }
                    for (int i = 0; i < MaxHepaCount; i++) Data[i] = rpmDataList[i];
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime) IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                //Error
                //1  Input Pressure Over
                //2  Input Pressure Under
                //4  Input Current Over
                //8  Over Temperture
                //10  Driver Error
                //8000  Communication Error
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)MayAirModbusAddress.AlarmCode, MaxHepaCount, out alarmDataList))
                {
                    if (alarmDataList == null) return;
                    if (IsNull || IsFail) return;
                    for (int i = 0; i < MaxHepaCount; i++) Data[i + 20] = alarmDataList[i];
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
            }
            catch (Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        //Device Command
        public bool HepaMannulSpeedSwitch(int speed)
        {
            try
            {
                if (mayAirController == null) return false;
                if (!mayAirController.mAdam.Connected) return false;
                mayAirController.mAdam.Modbus(mayAirController.SlaveID).PresetSingleReg(1011 + deviceNo, speed);
                SpinWait.SpinUntil(() => false, 100);
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaOff()
        {
            try
            {
                if (mayAirController == null) return false;
                if (!mayAirController.mAdam.Connected) return false;
                mayAirController.mAdam.Modbus(mayAirController.SlaveID).PresetSingleReg(1011 + deviceNo, 0);
                SpinWait.SpinUntil(() => false, 100);
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaLowSpeedSwitch()
        {
            try
            {
                if (mayAirController == null) return false;
                if (!mayAirController.mAdam.Connected) return false;
                mayAirController.mAdam.Modbus(mayAirController.SlaveID).PresetSingleReg(1011 + deviceNo, Model.FM_Setting.HepaRPM_L);
                SpinWait.SpinUntil(() => false, 100);
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaMedSpeedSwitch()
        {
            try
            {
                if (mayAirController == null) return false;
                if (!mayAirController.mAdam.Connected) return false;
                mayAirController.mAdam.Modbus(mayAirController.SlaveID).PresetSingleReg(1011 + deviceNo, Model.FM_Setting.HepaRPM_M);
                SpinWait.SpinUntil(() => false, 100);
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaHighSpeedSwitch()
        {
            try
            {
                if (mayAirController == null) return false;
                if (!mayAirController.mAdam.Connected) return false;
                mayAirController.mAdam.Modbus(mayAirController.SlaveID).PresetSingleReg(1011 + deviceNo, Model.FM_Setting.HepaRPM_H);
                SpinWait.SpinUntil(() => false, 100);
                return true;
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }

        // Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs(11, 1, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public void Initial() { }
        public bool Reset() => true;
        public bool HepaModeDefaultValueSetting() => true;

        #endregion
    }
}
