﻿using Advantech.Adam;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class AirTechFFU : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> adEnumList = EnumValues.Get<HepaDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;
        #endregion

        #region Constructors

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public AirTechFFU(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            DataArrayMaxLength = adEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }

        #endregion

        #region IModbusDevice メンバ

        public string DeviceName { get; set; } = DeviceType.AirTechFFU.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }
        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = true;
        public string DeviceIP { get; set; }

        // DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] rpmDataList;
            int[] alarmDataList;
            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                // Read registers (4X references)
                //RPM 40006(R)  
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)AirTechModbusAddress.RPM, 1, out rpmDataList))
                {
                    // Null處理
                    if (rpmDataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }
                    // Normal處理
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;
                    }                  
                    Data[(int)HepaDataIndex.RPM] = rpmDataList[0];
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                // Status 40005
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)AirTechModbusAddress.Status, 1, out alarmDataList))
                {
                    if (alarmDataList == null) return;
                    if (IsNull || IsFail) return;

                    Data[(int)HepaDataIndex.SpeedMode] = 0;
                    for (int i = 0; i < 16; i++)
                    {
                        var intOn = 1 << i;
                        var tmp = alarmDataList[0] & intOn;
                        {
                            switch (i)
                            {
                                case 0: //SpeedMode1
                                    if (tmp > 0) Data[(int)HepaDataIndex.SpeedMode] = 1;
                                    break;
                                case 1: //SpeedMode2
                                    if (tmp > 0) Data[(int)HepaDataIndex.SpeedMode] = 2;
                                    break;
                                case 2: //SpeedMode3
                                    if (tmp > 0) Data[(int)HepaDataIndex.SpeedMode] = 3;
                                    break;
                                case 7: //RunningStatus
                                    if (tmp > 0) Data[(int)HepaDataIndex.RunningStatus] = 1;
                                    else Data[(int)HepaDataIndex.RunningStatus] = 0;
                                    break;
                                case 4: //驅動器異常
                                case 15: //異常跳脫
                                    if (tmp > 0) Data[(int)HepaDataIndex.HepaAlarm] = 1;
                                    else Data[(int)HepaDataIndex.HepaAlarm] = 0;
                                    break;
                                default:
                                    break;
                            }
                        }
                    }
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }

                #region EC(電流) 40003(R) 保留
                //if (mAdam.Modbus(SlaveID).ReadHoldingRegs(AirTechModbusAddress.Current, 1, out iData3))
                //{
                //    Data[5] = iData3[0];
                //}
                #endregion
            }

            catch (Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        // Device Control    
        public bool HepaOff()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg(9, 64);
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaLowSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg(9, 1);
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaMedSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg(9, 2);
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaHighSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg(9, 4);
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaModeDefaultValueSetting()
        {
            try
            {
                if (!mAdam.Connected) return false;
                int[] temp = new int[] { Model.FM_Setting.HepaRPM_L,
                                    Model.FM_Setting.HepaRPM_M,
                                    Model.FM_Setting.HepaRPM_H };
                return mAdam.Modbus(SlaveID).PresetMultiRegs(29, temp);
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }

        //Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs(6, 1, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        //Unuse
        public bool Reset() => true;
        public void Initial() { }
        public bool HepaMannulSpeedSwitch(int speed) => true;
        #endregion
    }
}
