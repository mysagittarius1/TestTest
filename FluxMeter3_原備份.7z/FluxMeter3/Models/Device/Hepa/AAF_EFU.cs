﻿using Advantech.Adam;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class AAF_EFU : IModbusDevice
    {
        #region Member
        const int FailRetryTime = 10;
        AdamSocket mAdam;
        List<int> adEnumList = EnumValues.Get<HepaDataIndex>().Select(x => (int)x).ToList();
        int DataArrayMaxLength = 0;
        #endregion

        #region Constructors
        public AAF_EFU(int aSlaveID, AdamSocket aAdam)
        {
            mAdam = aAdam;
            DeviceIP = mAdam.GetIP();
            SlaveID = aSlaveID;
            DataArrayMaxLength = adEnumList.Last() + 1;
            Data = new int[DataArrayMaxLength];
        }
        #endregion

        #region IModbusDevice メンバ
        public string DeviceName { get; set; } = DeviceType.AAF_EFU.ToAliasName();
        public string DeviceVersion { get; set; } = "1.0.0.3";
        public int SlaveID { get; set; } = 0;
        public int[] Data { get; set; }
        public int StatisticsStep { get; set; }
        public bool IsNull { get; set; } = true;
        public bool IsFail { get; set; } = false;
        public int FailCount { get; set; } = 0;
        public bool IsHepa { get; set; } = true;
        public string DeviceIP { get; set; }

        //DataRefresh
        public void DataRefresh()
        {
            if (!mAdam.Connected) return;
            int[] rpmDataList;
            int[] alarmDataList;
            if (FailCount >= FailRetryTime) FailCount = 0;

            try
            {
                if (mAdam.Modbus(SlaveID).ReadInputRegs((int)AAFModbusAddress.RPM, 1, out rpmDataList))
                {
                    // Null處理
                    if (rpmDataList == null)
                    {
                        if (!IsNull)
                        {
                            FailCount++;
                            if (FailCount >= FailRetryTime) IsNull = true;
                            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                        }
                        return;
                    }
                    // Normal處理
                    if (IsNull)
                    {
                        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                        IsNull = false;
                    }
                    Data[(int)HepaDataIndex.RPM] = rpmDataList[0];
                    FailCount = 0;
                }
                else
                {
                    if (!IsFail)
                    {
                        FailCount++;
                        if (FailCount >= FailRetryTime)
                            IsFail = true;
                        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                    }
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }
                SpinWait.SpinUntil(() => false, 100);

                if (mAdam.Modbus(SlaveID).ReadInputRegs((int)AAFModbusAddress.AlarmCode, 1, out alarmDataList))
                {
                    if (alarmDataList == null) return;
                    if (IsNull || IsFail) return;
                    Data[(int)HepaDataIndex.HepaAlarm] = alarmDataList[0];
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                    return;
                }

                #region Old Version Hepa For Truly
                // Read registers (4X references)
                //RPM 0x04(R)  
                //if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)AAFModbusAddress.RPM, 1, out rpmDataList))
                //{
                //    // Null處理
                //    if (rpmDataList == null)
                //    {
                //        if (!IsNull)
                //        {
                //            FailCount++;
                //            if (FailCount >= FailRetryTime) IsNull = true;
                //            if (IsNull) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Null & Slave Number:" + SlaveID);
                //        }
                //        return;
                //    }
                //    // Normal處理
                //    if (IsNull)
                //    {
                //        Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Successful & Slave Number:" + SlaveID);
                //        IsNull = false;
                //    }
                //    Data[(int)HepaDataIndex.RPM] = rpmDataList[0];
                //    FailCount = 0;
                //}
                //else
                //{
                //    if (!IsFail)
                //    {
                //        FailCount++;
                //        if (FailCount >= FailRetryTime)
                //            IsFail = true;
                //        if (IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Fail & Slave Number:" + SlaveID);
                //    }
                //    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                //    return;
                //}
                //SpinWait.SpinUntil(() => false, 100);


                // AlarmCode 0x03h(R/W)
                //1  通訊錯誤(CPU)
                //2  IPM 過熱
                //3  IPM 溫度偵測過熱
                //4  IPM 模組異常保護(含 Over Current 保護)
                //9  風扇啟動錯誤
                //254  轉速一分鐘內未達設定值
                //255  通訊異常
                //if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)AAFModbusAddress.AlarmCode, 1, out alarmDataList))
                //{
                //    if (alarmDataList == null) return;
                //    if (IsNull || IsFail) return;
                //    Data[(int)HepaDataIndex.HepaAlarm] = alarmDataList[0];
                //}
                //else
                //{
                //    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                //    return;
                //}
                #endregion
            }
            catch (Exception ex)
            {
                if (!IsFail) Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                IsFail = true;
                return;
            }
        }

        //Recovery
        public void Recovery()
        {
            try
            {
                if (!mAdam.Connected) return;
                int[] recoveryDataList;
                if (mAdam.Modbus(SlaveID).ReadHoldingRegs((int)AAFModbusAddress.RPM, 1, out recoveryDataList))
                {
                    Model.ModbusDevice.AddCommentLog(DeviceName + "_Data Read Recovery & Slave Number:" + SlaveID);
                    IsFail = false;
                }
                else
                {
                    if (Model.ModbusDevice.IsEki) SpinWait.SpinUntil(() => false, 1500);
                }
                SpinWait.SpinUntil(() => false, 100);
            }
            catch (Exception ex)
            {
                return;
            }
        }

        // Device Control
        //0x00 On/Off
        //0x01 RPM Setting
        public bool HepaMannulSpeedSwitch(int speed)
        {
            try
            {
                if (!mAdam.Connected) return false;               
                return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.RPM, speed);

                #region For Truly
                //if (!mAdam.Connected) return false;
                //if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.SpeedSetting, speed)) return false;
                //SpinWait.SpinUntil(() => false, 100);
                //return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.PowerSwitch, (int)DevicePowerCommand.On);
                #endregion
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaOff()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.RPM, 0);

                #region For Truly
                //if (!mAdam.Connected) return false;
                //return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.PowerSwitch, (int)DevicePowerCommand.Off);
                #endregion
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaLowSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.RPM, Model.FM_Setting.HepaRPM_L);

                #region Old Version Hepa For Truly
                //if (!mAdam.Connected) return false;
                //if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.SpeedSetting, Model.FM_Setting.HepaRPM_L)) return false;
                //SpinWait.SpinUntil(() => false, 100);
                //return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.PowerSwitch, (int)DevicePowerCommand.On);
                #endregion
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaMedSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.RPM, Model.FM_Setting.HepaRPM_M);

                #region For Truly
                //if (!mAdam.Connected) return false;
                //if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.SpeedSetting, Model.FM_Setting.HepaRPM_M)) return false;
                //SpinWait.SpinUntil(() => false, 100);
                //return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.PowerSwitch, (int)DevicePowerCommand.On);
                #endregion
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }
        public bool HepaHighSpeedSwitch()
        {
            try
            {
                if (!mAdam.Connected) return false;
                return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.RPM, Model.FM_Setting.HepaRPM_H);

                #region Old Version Hepa For Truly
                //if (!mAdam.Connected) return false;
                //if (!mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.SpeedSetting, Model.FM_Setting.HepaRPM_H)) return false;
                //SpinWait.SpinUntil(() => false, 100);
                //return mAdam.Modbus(SlaveID).PresetSingleReg((int)AAFModbusAddress.PowerSwitch, (int)DevicePowerCommand.On);
                #endregion
            }
            catch (Exception ex)
            {
                Model.ModbusDevice.AddCommentLog(DeviceName + "_" + ex.ToString() + " & Slave Number: " + SlaveID);
                return false;
            }
        }

        //Unuse
        public bool HepaModeDefaultValueSetting() => true;
        public bool Reset() => true;
        public void Initial() { }
        #endregion

    }
}
