﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    // Data Transfer Test 20190425 For Test
    [Serializable]
    public sealed class ShowDataRecord
    {
        const string FileName = "DataRec.xml";
        public List<string> RecTitle { get; set; } = new List<string>();
        public List<double> RecData { get; set; } = new List<double>();
        public ShowDataRecord(List<string> title, List<double> data)
        {
            var path = StartUp.GetPath(true, FileName);
            RecTitle = title;
            RecData = data;
        }
        public ShowDataRecord()
        {
            
        }


        public static ShowDataRecord Load()
        {
            try
            {
                return XmlSerializer.Deserialize<ShowDataRecord>(StartUp.GetPath(true, FileName));
            }
            catch
            {
                return new ShowDataRecord();
            }
        }

        public void Save()
        {
            try
            {
                XmlSerializer.Serialize(StartUp.GetPath(true, FileName), this);
            }
            catch
            {
                return;
            }
        }
    }
}
