﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    class StatisticData
    {
        public DateTime LoadTime { get; set; } = DateTime.Now;

        public List<DateTime> MonthList { get; set; } = new List<DateTime>();

        // 8個Device -> 12個月 -> 每天的data
        public List<DateRecord> RecordList { get; set; } = new List<DateRecord>();

        public StatisticData()
        {
            for (int i = 0; i < 12; i++)
            {               
                DateTime aTitleDatetime = LoadTime.AddDays(-LoadTime.Day + 1);
                aTitleDatetime = aTitleDatetime.AddMonths(-11 + i);
                MonthList.Add(aTitleDatetime);

                DateRecord aRec = new DateRecord();
                aRec = aRec.Load(aTitleDatetime.Year, aTitleDatetime.Month);
                RecordList.Add(aRec);
            }
        }
    }
}
