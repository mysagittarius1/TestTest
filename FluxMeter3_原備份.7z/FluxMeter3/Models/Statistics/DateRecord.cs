﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class DateRecItem
    {
        public int RecordID { get; set; }
        public List<double> DataList { get; set; }
    }

    [Serializable]
    public sealed class DateRecord
    {
        private const int MaxDeviceRecordCount = 8;
        private const double DEFAULT_VALUE = 0.0d;

        private const string FileName = "DateRec";
        private const string FolderName = "Statistics";

        public List<DateRecItem> Statistics { get; set; }

        public DateRecord(int iYear, int iMonth)
        {
            var daysInMonth = DateTime.DaysInMonth(iYear, iMonth);

            var mIDs = Enumerable.Range(1, MaxDeviceRecordCount);
            var mDataList = Enumerable.Repeat(0.0d, daysInMonth).ToList();
            var mEmpty = mIDs.Select(x => new DateRecItem
            {
                RecordID = x,
                DataList = mDataList
            });
            Statistics = mEmpty.ToList();
        }
        public DateRecord()
        {
        }

        public DateRecord Load(int iYear, int iMonth)
        {
            string path = $"{FileName}_{iYear}_{iMonth:00}.xml";
            try
            {               
                return XmlSerializer.Deserialize<DateRecord>(StartUp.GetPath(true, FolderName, path), null);
            }
            catch
            {
                return new DateRecord(iYear, iMonth);
            }
        }

        public void Save(int iRecYear, int iRecMonth)
        {           
            var mFileName = string.Format("{0}_{1:0000}_{2:00}.xml", FileName, iRecYear, iRecMonth);
            XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, mFileName), this);

        }
    }
}
