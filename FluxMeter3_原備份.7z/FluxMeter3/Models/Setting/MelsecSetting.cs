﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Otsukaele;
using Otsukaele.Serialization;
using Otsukaele.PLC.Settings;

namespace FluxMeter3.Models
{
    [Serializable]
    public sealed class MelsecSetting
    {
        const string FileName = "MelsecSetting.xml";
        const string FolderName = "Setting";

        public PLCCondition Plc { get; set; } = new PLCCondition { IsDebug = true };

        public static MelsecSetting Load()
        {
            MelsecSetting ret;
            try
            {
                ret = XmlSerializer.Deserialize<MelsecSetting>(StartUp.GetPath(true, FolderName, FileName));
            }
            catch
            {
                ret = new MelsecSetting();
            }
            if (ret.Plc.IsDebug) Model.AddLog("PLC Debug Mode", FolderName);
            return ret;
        }

        public void Save()
        {
            XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, FileName), this);
        }
    }

    
}
