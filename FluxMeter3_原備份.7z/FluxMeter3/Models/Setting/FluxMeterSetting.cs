﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    [Serializable]
    public sealed class FluxMeterSetting
    {
        const string FileName = "FluxMeterSetting.xml";
        const string FolderName = "Setting";

        const int MaxCount = 128;

        public bool IsDebug { get; set; }

        public string IpAddress { get; set; }

        public int PortNo { get; set; }

        public int ConnTimeout { get; set; }

        public int SendTimeout { get; set; }

        public int RecvTimeout { get; set; }

        public bool IsReadFromPLC { get; set; }

        public bool IsTestMode { get; set; }

        public string PW_Key { get; set; }

        public int HepaRPM_L { get; set; }

        public int HepaRPM_M { get; set; }

        public int HepaRPM_H { get; set; }

        public bool IsHepaControl { get; set; }

        public bool IsHepaSpeedControlByUser { get; set; }

        public bool IsHepaControlByDoor { get; set; }     

        public int[] Devices { get; set; }

        public FluxMeterSetting()
        {
            Devices = new int[MaxCount];
        }

        public FluxMeterSetting(int[] datas)
        {
            Devices = datas;
        }

        public static FluxMeterSetting Load()
        {
            FluxMeterSetting ret;
            try
            {
                ret = XmlSerializer.Deserialize<FluxMeterSetting>(StartUp.GetPath(true, FolderName, FileName));
            }           
            catch
            {
                ret = new FluxMeterSetting();
            }
            if (ret.IsDebug) Model.AddLog("FluxMeter Debug Mode", FolderName);
            return ret;
        }

        public void Save()
        {
           XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, FileName), this);
        }
    }
}
