﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class LampExItem
    {
        public int Reset_SlaveID { get; set; }          //Slave ID
        public int Reset_WordNo { get; set; }           //Value Index
    }


    [Serializable]
    public sealed class LampExSetting
    {
        private const string FileName = "LampExSetting.xml";
        private const string FolderName = "Setting";

        private const int MaxCount = 8;

        public LampExItem[] LampEx { get; set; }

        public LampExSetting(LampExItem[] datas)
        {
            LampEx = datas;
        }

        public LampExSetting()
        {
            var mEmpty = Enumerable.Repeat(new LampExItem { Reset_SlaveID = 0, Reset_WordNo = 1 }, MaxCount);
            LampEx = mEmpty.ToArray();        
        }


        public static LampExSetting Load()
        {
            try
            {
                return XmlSerializer.Deserialize<LampExSetting>(StartUp.GetPath(true, FolderName, FileName));
            }
            catch
            {
                return new LampExSetting();
            }
        }

        public void Save()
        {
            XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, FileName), this);
        }
    }
}
