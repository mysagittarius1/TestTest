﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class ShowDataItem
    {
        public bool IsSupport { get; set; }     //サポート
        public string Name { get; set; }        //チャンネル名
        public string Unit { get; set; }        //表示単位
        public double MaxLimit { get; set; }    //上限リミット値
        public double MinLimit { get; set; }    //下限リミット値
        public double AX { get; set; }          //調整倍率
        public double BY { get; set; }          //切片
        public double ShowMax { get; set; }     //表示計測値
        public string MaxMsg { get; set; }      //上限警告メッセージ
        public string MinMsg { get; set; }      //下限警告メッセージ
        public int SlaveID { get; set; }        //Slave ID
        public int WordNo { get; set; }         //Value Index
        public bool IsReset { get; set; }       //RESET
    }


    [Serializable]
    public sealed class ShowDataSetting
    {
        private const string FileName = "ShowDataSetting.xml";
        private const string FolderName = "Setting";

        private const int MaxCount = 128;

        public ShowDataItem[] ShowData { get; set; }

        public ShowDataSetting(ShowDataItem[] datas)
        {
            ShowData = datas;
        }

        public ShowDataSetting()
        {
            var mEmpty = Enumerable.Repeat(new ShowDataItem {
                IsSupport = true,
                Name = "ShowData",
                Unit = "mm",
                MaxLimit = 999.9,
                MinLimit = 0.0,
                AX = 1.0,
                BY = 0.0,
                ShowMax = 99999.0,
                MaxMsg = "Over Max",
                MinMsg = "Over Min",
                SlaveID = 1,
                WordNo = 1,
                IsReset = false },
                MaxCount);
            ShowData = mEmpty.ToArray();
        }


        public static ShowDataSetting Load()
        {
            try
            {
                return XmlSerializer.Deserialize<ShowDataSetting>(StartUp.GetPath(true, FolderName, FileName));
            }
            catch
            {
                return new ShowDataSetting();
            }
        }

        public void Save()
        {
            XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, FileName), this);
        }
    }
}
