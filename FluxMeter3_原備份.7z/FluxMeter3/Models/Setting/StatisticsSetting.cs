﻿using Otsukaele;
using Otsukaele.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class StatisticsItem
    {
        public bool IsSupport { get; set; }         //サポート
        public string Name { get; set; }            //チャンネル名
        public string Unit { get; set; }            //表示単位
        public int Type { get; set; }            //Devic Type
        public int Address { get; set; }            //Address
        public DateTime ResetDateTime { get; set; }   //RESET DateTime (by day)
    }


    [Serializable]
    public sealed class StatisticsSetting
    {
        private const string FileName = "StatisticsSetting.xml";
        private const string FolderName = "Setting";

        private const int MaxCount = 8;

        public StatisticsItem[] Statistics { get; set; }

        public StatisticsSetting(StatisticsItem[] datas)
        {
            Statistics = datas;
        }

        public StatisticsSetting()
        {
            var mEmpty = Enumerable.Repeat(new StatisticsItem
            {
                IsSupport = true,
                Name = "Device",
                Unit = "Unit",
                Type = 1,
                ResetDateTime = DateTime.Now
            },
                MaxCount);
            Statistics = mEmpty.ToArray();
        }

        public static StatisticsSetting Load()
        {
            try
            {
                return XmlSerializer.Deserialize<StatisticsSetting>(StartUp.GetPath(true, FolderName, FileName));
            }
            catch
            {
                return new StatisticsSetting();
            }
        }

        public void Save()
        {
            XmlSerializer.Serialize(StartUp.GetPath(true, FolderName, FileName), this);
        }
    }
}
