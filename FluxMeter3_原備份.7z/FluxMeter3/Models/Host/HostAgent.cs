﻿using Otsukaele.PLC;
using Otsukaele.PLC.Settings;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    sealed class HostAgent
    {
        [Offset(0)] //Offset属性を付与することでEnum全体にオフセットをかけることができます
        public enum Address
        {
            [Address(Device.M, 3000)]
            FM_ErrorWriteArea,

            [Address(Device.D, 0, ReadSize = 32*2)]
            FM_ValueReadArea,

            [Address(Device.D, 3000)]
            FM_ValueWriteArea,

            [Address(Device.D, 500)]
            DoorMonitor,
        }

        const string LogName = "Host";
        const int DataArrayMaxCount = 32;


        PLCControl _comm;
        int[] _readDataFromPlcArray;
        bool _isIntialized = false;

        CommandDefine[] _deviceCommandForPlcArray;

        MemoryMappedFile _mmf = MemoryMappedFile.CreateNew("Utility", 256);

        public EquipmentDoorStatus DoorStatus { get; set; } = EquipmentDoorStatus.None;
        public bool IsDoorStatusChange { get; set; } = false;

        public bool IsConnected { get; private set; }


        /// <summary>
        /// コンストラクタ
        /// </summary>
        public HostAgent()
        {
            _readDataFromPlcArray = Enumerable.Repeat(0, DataArrayMaxCount).ToArray();
            _deviceCommandForPlcArray = Enumerable.Repeat(CommandDefine.None, DataArrayMaxCount).ToArray();
            Task.Run(() => PLC_Task());
        }
        ~HostAgent()
        {
            _mmf.Dispose();
        }


        /// <summary>
        /// 初期化
        /// </summary>
        public void Initialize()
        {          
            _comm = new PLCControl(Model.PlcSetting.Plc);
            _comm.ChangeOffset<Address>(0);
            _comm.SetParameters<Address>();

            // PLC接続
            if (!PLC_Connect()) return;
            _isIntialized = true;          
        }

        public bool PLC_Connect()
        {
            if (Model.PlcSetting.Plc.IsDebug) return true;

            bool ret = true;
            try
            {
                // 接続中止
                if (IsConnected)
                {
                    _comm.Close();
                    IsConnected = false;
                }
                // PLC接続
                _comm.Open();
                IsConnected = true;
            }
            catch (Exception ex)
            {
                Model.AddLog(ex.Message);
                IsConnected = false;
                ret = false;
            }
            return ret;
        }

        void PLC_Task()
        {
            while (true)
            {
                DevicesMonitor();
                SpinWait.SpinUntil(() => false, 50);
            }
        }

        void DevicesMonitor()
        {
            if (!_isIntialized) return;
            if (Model.PlcSetting.Plc.IsDebug) return;
            if (!IsConnected) return;

            //Door Monitor -> EFU
            var doorStatusFromPlc = (EquipmentDoorStatus)_comm.ReadWord(Address.DoorMonitor, 1).Word;
            if (DoorStatus != doorStatusFromPlc)
            {
                DoorStatus = doorStatusFromPlc;
                IsDoorStatusChange = true;
            }

            var PlcVal = _comm.ReadWord(Address.FM_ValueReadArea, DataArrayMaxCount * 2);
            for (var i = 0; i < _readDataFromPlcArray.Length; i++)
            {
                var val = PlcVal.Words[i * 2 + 1] << 16;
                val += PlcVal.Words[i * 2];
                _readDataFromPlcArray[i] = val;
            }

            for (var i = 0; i < _deviceCommandForPlcArray.Length; i++)
            {
                if (_deviceCommandForPlcArray[i] != CommandDefine.ResetCommand) continue;

                WriteReset(i).Wait();
                _deviceCommandForPlcArray[i] = CommandDefine.None;
                Model.AddLog(Model.ST_Setting.Statistics[i].Name + " Statistics Plc Value Reset Successful", LogName);
            }
        }


        async Task WriteReset(int iIdx)
        {
            var device = Address.FM_ValueReadArea.ToParameter();
            device.Index += iIdx;
            await _comm.WriteAsync(device, new int[] { 0,0 })
                   .ConfigureAwait(false);
        }

        #region Share Memory 保存 Data Transfer Test 20190425 For Test
        //Share Memory
        //public void MMF_Write(ShowDataRecord data)
        //{
        //    try
        //    {
        //        using (var stream = mmf.CreateViewStream())
        //        {
        //            var binFormatter = new BinaryFormatter();
        //            var writer = new BinaryWriter(stream);
        //            writer.Flush();

        //            foreach (var item in data.RecData)
        //            {
        //                writer.Write(item);
        //            }
        //        }
        //    }
        //    catch
        //    {
        //        return;
        //    }
        //}
        #endregion

        public async Task WriteValues(double[] datas, bool[] blnArray)
        {
            if (Model.PlcSetting.Plc.IsDebug) return;
            if (!IsConnected) return;

            //　書き込み処理
            var writearea = new int[datas.Length * 2];
            for (var i = 0; i < datas.Length; i++)
            {
                var intValue = Convert.ToInt32(datas[i]);
                writearea[2 * i] = 0xFFFF & intValue;
                writearea[2 * i + 1] = 0xFFFF & (intValue >> 16);
            }

            // Datas
            await _comm.WriteAsync(Address.FM_ValueWriteArea, writearea)
                   .ConfigureAwait(false);

            // Error
            await _comm.WriteAsync(Address.FM_ErrorWriteArea, blnArray)
                   .ConfigureAwait(false);
        }

        #region DWord處理-保留
        //public int GetDWordValue(int iIdx)
        //{
        //    int ret = 0;

        //    if (iIdx < 1) return ret;
        //    if (iIdx > 8) return ret;

        //    var mValue = comm.ReadWord(mFM2_DWORDList[iIdx - 1], 2);
        //    ret = mValue.TwoWord;
        //    return ret;
        //}
        //private async Task WriteDWord(int iIdx, int[] intArray)
        //{
        //    comm.WriteRequest(mFM2_DWORDList[iIdx], intArray);
        //    await comm.WriteAsync(mFM2_DWORDList[iIdx], intArray)
        //           .ConfigureAwait(false);
        //}
        #endregion

        public void SetPlcValueReset(int index)
        {
            if (index < 1) return;
            if (index > DataArrayMaxCount) return;
            _deviceCommandForPlcArray[index - 1] = CommandDefine.ResetCommand;
        }

        public int GetPlcValue(int index)
        {
            if (Model.PlcSetting.Plc.IsDebug) return 0;
            if (index < 1) return 0;
            if (index > DataArrayMaxCount) return 0;
            return _readDataFromPlcArray[index - 1];
        }
    }
}
