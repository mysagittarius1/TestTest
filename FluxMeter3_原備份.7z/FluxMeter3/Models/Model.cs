﻿using FluxMeter3.Views;
using Otsukaele;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    static class Model
    {
        //public static AllSettings All_Settings { get; set; }
        public static FluxMeterSetting FM_Setting { get; set; }

        public static LampExSetting LE_Setting { get; set; }

        public static StatisticsSetting ST_Setting { get; set; }

        public static ShowDataSetting SD_Setting { get; set; }

        public static MelsecSetting PlcSetting { get; set; }

        public static HostAgent Host { get; set; }

        public static ModbusGateway ModbusDevice { get; set; }

        public static List<ShowDataValue> ShowDataItemList { get; set; }

        public static ErrorManager ErrorManager { get; set; }

        static System.Version _version;
        static string _title;
        public static string Title
        {
            get
            {
                if (_title.IsNullOrEmpty())
                {
                    var assembly = Assembly.GetExecutingAssembly().GetName();
                    _version = assembly.Version;
                    _title = assembly.Name + " " + _version;
                }
                return _title;
            }
        }

        static Log _log = Log.CreateInstance(30, true);
        public static void AddLog(string msg) => _log.AddLog(msg, "-");
        public static void AddLog(string msg, string device) => _log.AddLog(msg, device);

        public static void Initialize()
        {           
            // 設定が読込
            FM_Setting = FluxMeterSetting.Load();
            LE_Setting = LampExSetting.Load();
            ST_Setting = StatisticsSetting.Load();
            SD_Setting = ShowDataSetting.Load();
            PlcSetting = MelsecSetting.Load();

            // PLC初期化
            Host = new HostAgent();
            Host.Initialize();
            // EKI初期化           
            ModbusDevice = new ModbusGateway();
            ModbusDevice.Initialize();
            //ShowValue Load
            Show_Value_Instance();
            // ErrorManager初期化
            ErrorManager = new ErrorManager();

            Task.Run(() => Model_Task());
        }


        public static void Show_Value_Instance()
        {
            ShowDataItemList = SD_Setting.ShowData.Where(x => x.IsSupport)
                                      .Select(x => new ShowDataValue(x)).ToList();
        }

        static void Model_Task()
        {
            if (PlcSetting.Plc.IsDebug)
                AddLog("PLC Debug Mode");

            while (true)
            {
                #region Data Transfer Test 20190425 For Test
                //FileWriteTest();
                //MMFWriteTest();
                #endregion

                ShowDataRefresh();
                StatisticsDataResetCheck();
                SpinWait.SpinUntil(() => false, 50);
            }
        }

        #region Data Transfer Test 20190425 For Test

        //static double t1 = 0.1234;
        //static void FileWriteTest()
        //{
        //    t1++;
        //    ShowDataRecord test = new ShowDataRecord(
        //        Enumerable.Repeat("Test" + t1, 5).ToList(),
        //        Enumerable.Repeat(0.0 + t1, 5).ToList());

        //    test.Save();
        //    SpinWait.SpinUntil(() => false, 500);
        //}

        //static void MMFWriteTest()
        //{
        //    t1++;
        //    ShowDataRecord test = new ShowDataRecord(
        //        Enumerable.Repeat("Test" + t1, 5).ToList(),
        //        Enumerable.Repeat(0.0 + t1, 5).ToList());

        //    Host.MMF_Write(test);
        //    SpinWait.SpinUntil(() => false, 500);
        //}

        #endregion

        static void ShowDataRefresh()
        {
            try
            {
                //Modbus Disconnect All Value is 0
                if (!ModbusDevice.IsConnected())
                {
                    foreach (var item in ShowDataItemList) item.ShowValue = 0;
                    return;
                }              
                
                #region Fluxmeter Data
                for (int i = 0; i < ShowDataItemList.Count; i++)
                {                   
                    ShowDataValue aSetting = ShowDataItemList[i];

                    if (ModbusDevice.ModbusDevicesArray[aSetting.SlaveID - 1].DeviceName == null) continue;

                    int iValue = 0;
                    DeviceType aEnum = (DeviceType)Enum.ToObject(typeof(DeviceType), FM_Setting.Devices[aSetting.SlaveID - 1]);

                    if (aSetting.SlaveID == -1)
                    {
                        // SlaveID = -1 -> Get Data from PLC
                        iValue = Host.GetPlcValue(aSetting.WordNo);
                    }
                    else
                    {
                        // ModbusDevice -> Device Read Null or Fail continue
                        if (ModbusDevice.ModbusDevicesArray[aSetting.SlaveID - 1].IsFail ||
                            ModbusDevice.ModbusDevicesArray[aSetting.SlaveID - 1].IsNull)
                        {
                            aSetting.ShowValue = 0;
                            continue;
                        }

                        // Get Data from Modbus
                        iValue = ModbusDevice.GetData(aSetting.SlaveID, aSetting.WordNo);
                    }

                    double tmpVal = (double)iValue - aSetting.BY;
                    double dValue = 0;

                    // AD Convert Offset
                    if ((aEnum == DeviceType.ADAM_4017P) || (aEnum == DeviceType.IOLOGIK_E1240))
                    {
                        if (iValue == 0xFFFF) tmpVal = 0;
                        if (iValue == 0) tmpVal = 0;

                        #region Offset說明
                        /*
                            公式使用要點：
                            由於公式是固定的 1000 / 32768 * (Adam_Value - BY) * AX = 錶頭值 

                            正數範例：假設(錶頭Range 0 ~ 1000)，錶頭值500
                            1000 / 65536 * (32768(Adam_Value) - BY) * AX = 500(錶頭值)                                
                            與目前公式比較，乘積1000 / 32768 = 0.03052 為 1000 / 65536 = 0.01526之2倍
                            故BY可設0，AX設為0.5。

                            負數範例：假設(錶頭Range -100 ~ 100)，錶頭值-10                    
                            200 / 65536 * (3276.8(Adam_Value) - BY) * AX = -10(錶頭) 
                            由於需判定正負，BY的部分需先設為32768
                            如減完 BY(32768)為負數，下面需另外處理
                            與目前公式比較，乘積1000 / 32768 = 0.03052 為 200 / 65536 = 0.003052之10倍
                            故AX設為0.1。
                        */
                        #endregion

                        // 正數
                        if (tmpVal >= 0)
                        {
                            dValue = (1000 / Math.Pow(2, 15) * tmpVal) * aSetting.AX;
                        }
                        // 2019/04/11 新增負數處理Test                        
                        else
                        {
                            // (錯誤)錶頭 = -10 -> 0.03052(3276.8 - 32768) * 0.1 = -90 (如用正數算法是錯誤的)
                            // (正確)錶頭 = -10 -> 0.03052 * -3276.8 * 0.1 = -10(正確)
                            tmpVal = (double)iValue;
                            dValue = (1000 / Math.Pow(2, 15) * (-tmpVal)) * aSetting.AX;
                        }
                    }
                    else
                    {
                        // 如非AD轉換模組有Value修正需求，可使用AX
                        dValue = tmpVal * aSetting.AX;
                    }

                    int JudgeDeciaml = aSetting.AX.ToString().IndexOf('.');
                    if (JudgeDeciaml >= 0)
                    {
                        int idx = aSetting.AX.ToString().Length - JudgeDeciaml - 1;
                        if (idx >= 0)
                            dValue = Math.Round(dValue, idx);
                    }

                    if ((aSetting.ShowMax != 0) && (dValue > aSetting.ShowMax))
                        dValue = aSetting.ShowMax;

                    aSetting.ShowValue = dValue;

                    switch(aEnum)
                    {
                        // PowerMeter、Counter Don't Need MaxLimit & MinLimit.
                        case DeviceType.KM_50:
                        case DeviceType.CTA_4001D:
                        case DeviceType.DPM_C530:
                            continue;
                        // Hepa Need Alarm Check. Don't Need MaxLimit & MinLimit.
                        case DeviceType.AirTechFFU:
                        case DeviceType.AAF_EFU:
                        case DeviceType.MayAir_EA21:
                            aSetting.Err = ModbusDevice.GetData(aSetting.SlaveID, (int)HepaDataIndex.HepaAlarm + 1);
                            continue;
                        default:
                            // Other Device Need Value Limit Monitor
                            if (aSetting.ShowValue > aSetting.MaxLimit)
                                aSetting.Err = (int)ShowValueErrorDefine.MaximumError;
                            else if (aSetting.ShowValue < aSetting.MinLimit)
                                aSetting.Err = (int)ShowValueErrorDefine.MinimumError;

                            else if ((aSetting.MaxLimit == aSetting.ShowValue) ||
                                        (aSetting.MinLimit == aSetting.ShowValue))
                                aSetting.Err = (int)ShowValueErrorDefine.OnLimit;
                            else
                                aSetting.Err = (int)ShowValueErrorDefine.NoError;
                            break;
                    }               
                }

                #region Data Transfer Test 20190425 For Test
                //20190425 Test OK
                //var Title = SHOW_VALUES.Select(x => x.Name).ToList();
                //var FileValues = SHOW_VALUES.Select(x => x.ShowValue).ToList();

                // Write To File
                //ShowDataRecord aRec = new ShowDataRecord(Title, FileValues);
                //aRec.Save();

                // Write To Memory
                //Host.MMF_Write(aRec);
                #endregion

                var PlcValues = ShowDataItemList.Select(x => (x.ShowValue * 1000)).ToArray();
                var PlcErrs = ShowDataItemList.Select(x => (x.Err > 0)).ToArray();
                Host.WriteValues(PlcValues, PlcErrs).Wait();
                #endregion
                
            }
            catch(Exception ex)
            {
                ModbusDevice.AddCommentLog(ex.ToString());
            }

        }

        static void StatisticsDataResetCheck()
        {
            try
            {
                if (FM_Setting.IsDebug) return;
                if (!ModbusDevice.IsConnected()) return;
                var _isSavePama = false;
                var _checkDate = DateTime.Now;
                for (int i = 0; i < ST_Setting.Statistics.Count(); i++)
                {
                    if (!ST_Setting.Statistics[i].IsSupport) continue;        
                    
                    if (ST_Setting.Statistics[i].Type == (int)StatisticDataType.Plc)
                    {
                        // ResetDateTime < Now -> PLC Value Reset 通常用於氣量累計
                        bool result = GetPlcStatisticsValueThenReset(i, _checkDate);
                        if (result) _isSavePama = true;
                    }
                    else if(ST_Setting.Statistics[i].Type > (int)StatisticDataType.Plc)
                    {
                        // ResetDateTime < Now -> KM50 Statistic Value Reset
                        bool result = GetPowerMeterStatisticsValueThenReset(i, _checkDate);
                        if (result) _isSavePama = true;
                    }
                }
                if (_isSavePama) ST_Setting.Save();
            }
            catch(Exception ex)
            {
                ModbusDevice.AddCommentLog(ex.ToString());
            }
        }

        static bool GetPlcStatisticsValueThenReset(int idx, DateTime day)
        {
            // PLC Reset Function            
            // Use For Ionizer流量積算(By Day)：PLC Address = D0
            if (ST_Setting.Statistics[idx].ResetDateTime > day) return false;
            // Get Data
            var iValue = Host.GetPlcValue(ST_Setting.Statistics[idx].Address);
            AddLog(ST_Setting.Statistics[idx].Name + "'s Daily Value = " + iValue);
            // Plc Value Reset
            Host.SetPlcValueReset(ST_Setting.Statistics[idx].Address);
            // Data Save
            var _saveYear = day.Year;
            var _saveMonth = day.Month;
            var _statistics = ST_Setting.Statistics[idx];
            var _dateRecord = new DateRecord();
            _dateRecord = _dateRecord.Load(_saveYear, _saveMonth);
            _dateRecord.Statistics[idx].DataList[day.Day - 1] = (double)iValue;
            _dateRecord.Save(_saveYear, _saveMonth);
            // ResetDateTime + 1
            var _nextDate = day.AddDays(1);
            _statistics.ResetDateTime = new DateTime(_nextDate.Year, _nextDate.Month, _nextDate.Day, _statistics.ResetDateTime.Hour, _statistics.ResetDateTime.Minute, _statistics.ResetDateTime.Second);
            ST_Setting.Statistics[idx] = _statistics;
            AddLog(ST_Setting.Statistics[idx].Name + " Exexute Plc Value Reset By Day");
            return true;
        }

        static bool GetPowerMeterStatisticsValueThenReset(int idx, DateTime now)
        {
            // Use For PowerMeter(By Day) 
            if (ST_Setting.Statistics[idx].ResetDateTime > now) return false;

            var isSave = false;
            var dblValue = 0.0;
            var sType = (StatisticDataType)ST_Setting.Statistics[idx].Type;
            var sStatisticsStepStart = (PowerMeterStatisticsStep)sType;
            if ((int)sType > 1)
            {
                var iWord = 0;
                var dBase = 0.1;
                var iStatisticsStep = ModbusDevice.GetStatisticsStep(ST_Setting.Statistics[idx].Address);
                // Start Statistics Step 
                if (iStatisticsStep == 0)
                {                  
                    ModbusDevice.SetStatisticsStep(ST_Setting.Statistics[idx].Address, (int)sStatisticsStepStart);
                    return false;
                }

                // End Statistic Step, Set iWord
                if (sType == StatisticDataType.DPM_C530_Kwh && iStatisticsStep == (int)PowerMeterStatisticsStep.DPM_C530_KwhStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticKwh + 1;
                    dBase = 0.001;
                }
                else if(sType == StatisticDataType.KM50_Kwh && iStatisticsStep == (int)PowerMeterStatisticsStep.KM50_KwhStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticKwh + 1;
                }
                else if (sType == StatisticDataType.KM50_V && iStatisticsStep == (int)PowerMeterStatisticsStep.KM50_VStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticV + 1;
                }
                else if (sType == StatisticDataType.KM50_A && iStatisticsStep == (int)PowerMeterStatisticsStep.KM50_AStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticA + 1;
                    dBase = 0.001;
                }
                else if (sType == StatisticDataType.KM50_Kvar && iStatisticsStep == (int)PowerMeterStatisticsStep.KM50_KvarStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticKvar + 1;
                    dBase = 0.01;
                }
                else if (sType == StatisticDataType.KM50_Kva && iStatisticsStep == (int)PowerMeterStatisticsStep.KM50_KvaStatisticsEnd)
                {
                    iWord = (int)PowerMeterDataIndex.StatisticKva + 1;
                    dBase = 0.01;
                }

                if (iWord > 0)
                {
                    int iPowerMeterStatisticValue = ModbusDevice.GetStaticData(ST_Setting.Statistics[idx].Address, iWord);
                    dblValue = iPowerMeterStatisticValue * dBase;
                    ModbusDevice.AddCommentLog("Statistic " + ST_Setting.Statistics[idx].Name + "'s Daily Value = " + dblValue);
                    isSave = true;
                }
            }          
            if (!isSave) return false;

            // Data Save
            var _saveYear = now.Year;
            var _saveMonth = now.Month;
            var _statatics = ST_Setting.Statistics[idx];
            var _dateRecord = new DateRecord();
            _dateRecord = _dateRecord.Load(_saveYear, _saveMonth);
            _dateRecord.Statistics[idx].DataList[now.Day - 1] = dblValue;
            _dateRecord.Save(_saveYear, _saveMonth);
            ModbusDevice.ResetStatisticsStep(ST_Setting.Statistics[idx].Address);

            DateTime _nextDate = now.AddDays(1);
            _statatics.ResetDateTime = new DateTime(_nextDate.Year, _nextDate.Month, _nextDate.Day, _nextDate.Hour, _statatics.ResetDateTime.Minute, _statatics.ResetDateTime.Second);
            ST_Setting.Statistics[idx] = _statatics;
            ModbusDevice.AddCommentLog("Statistic " + ST_Setting.Statistics[idx].Name + " Exexute Modbus Device Statistic Reset By Day");
            return true;
        }
    }
}