﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class ErrorItem
    {
        public int ErrorID { get; set; } = 0;
        public string Message { get; set; } = string.Empty;
        public DateTime ReceiveTime { get; set; } = DateTime.Now;

        public ErrorItem(int errorID, string name, string message)
        {
            ErrorID = errorID;
            ReceiveTime = DateTime.Now;
            Message = $"[{ErrorID}]{name}_{message}";
        }
    }
}
