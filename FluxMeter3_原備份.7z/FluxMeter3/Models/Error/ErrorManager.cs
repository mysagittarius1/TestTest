﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FluxMeter3.Models
{
    public class ErrorManager
    {
        public ObservableCollection<ErrorItem> ErrorList = new ObservableCollection<ErrorItem>();

        public ErrorManager()
        {
        }

        public void AddError(ErrorItem aItem)
        {
            ErrorList.Add(aItem);
            if (ErrorList.Count > 20) ErrorList.RemoveAt(0);         
        }

        public void ClearError()
        {
            ErrorList.Clear();
        }
    }
}
