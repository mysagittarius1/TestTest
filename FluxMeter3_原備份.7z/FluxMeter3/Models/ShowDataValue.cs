﻿using FluxMeter3.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FluxMeter3.Models
{
    class ShowDataValue : ShowDataItem
    {
        public double ShowValue { get; set; }
        public int Err { get; set; }

        public ShowDataValue(ShowDataItem item) 
        {
            IsSupport = item.IsSupport;
            Name = item.Name;
            Unit = item.Unit;
            MaxLimit = item.MaxLimit;
            MinLimit = item.MinLimit;
            AX = item.AX;
            BY = item.BY;
            ShowMax = item.ShowMax;
            MaxMsg = item.MaxMsg;
            MinMsg = item.MinMsg;
            SlaveID = item.SlaveID;
            WordNo = item.WordNo;
            IsReset = item.IsReset;
            ShowValue = 0;
            Err = 0;
        }
    }
}
